using System;
using Newtonsoft.Json;

// STATIC members won't serialise
/*  I want whichever class is initialised first to cause the creation of the JSON in sbots
    global vars

    IF when this 01 is initialised (save and compile) it should ask the other class to update

    When the other class is initialised it should do a grab, possibly asking 01 to init

    POSSIBLE Flow
        reader NEVER calls its update method.  creator calls it on creation of the config.
        This means it'll also update
        COULD call a dummy method in 01 to prompt init.


    INFINITE LOOP PROBLEMS
*/

public class config
{
    public string test = "Test 3";
    public int testi = 321;
    public string teststrisint = "32767";
}


public class CPHInline
{
    public bool Execute()
    {        // your main code goes here
        return true;
    }

        // the messages here won't be seen on bot start up

    public void Init()
    {
    	create_config();

        say("01. in Init() is calling 02. update_config");
        bool res = CPH.ExecuteMethod("C# Config Reader", "update_config");
        say("YT Config setup() call result : " + res);
    }

    int cCount = 0, cCountLimit = 4;

    public bool create_config() {
        try {
            if (++cCount >= cCountLimit) {
                say($"create_config limit reached {cCountLimit}");
                return false;
            }
say($"01. create_content run : {cCount}");
			config con = new config();
			string json = JsonConvert.SerializeObject(con);
                // global, non permanent
			CPH.SetGlobalVar("CONFIG_TEST", json, false);
                // indicate to the other code that the config has been updated

			CPH.SendMessage("Set global YT Config Json length:" + json.Length, true);

        /*  bool RunAction(string actionName, bool runImmediately = true);
            bool RunActionById(string actionId, bool runImmediately = true);
            bool ExecuteMethod(string executeCode, string methodName); */
                // First params is NOT the name of the action but the Name from code settings

            //say("YT Config setup() call result : " + res);
    	} catch(Exception e) {
			CPH.SendMessage("Config Init Error:" + e.ToString(), true);

            return false;
    	}

        return true;
    }
        // tickle to case my creation
    public bool dummy() {
        return true;
    }

    // shortcut to Twitch message
    public void say(string w2s) {
        CPH.SendMessage(w2s, true);
    }
}