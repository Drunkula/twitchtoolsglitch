using System;
using Newtonsoft.Json; // STATIC members won't serialise

// ********** AFTER CHANGES USE THE COMMAND !ytinit or !yt init in chat **********
// ********** AFTER CHANGES USE THE COMMAND !ytinit or !yt init in chat **********
// ********** AFTER CHANGES USE THE COMMAND !ytinit or !yt init in chat **********

public class config
{
    public bool alwaysAddNext = true; // Whether !add will also add next.
    // playlist storage add on/off NOTE: After first run will be stored
    public bool permanentAddToPlaylist = false; // will become a stored persisted global

    // files
    public bool backupsEnabled = true; // file backups enabled
    public int totalDailyBackups = 8; // how many file backups to cycle through
    // storage location for the permanent playlist
    public string playlistFile = @"C:\mystuff\Streamerbot-DM\ytplaylists\youtube-playlist.json";
    // name of Streamerbot global variable to store they playlist either as a backup or instead of a file.
    public string playlistVarName = "yt_playlist_default"; // Streamerbot persistent global var name

    // google apikey
    public string apikey = "AIzaSyBRPuveJXC18b_bf6PIIUYFrkRwlGjK6P4";
    // RESPONSE MESSAGES - If you change these make a copy locally for when I update things

    // add reply messages store on/of, next on/off | PERMNEXT, PERMRAND, TEMPNEXT, TEMPRAND
    // messages can use tags {user}
    public string YT_URL_WRONG_MSG = "@{user} put the link for a youtube video in, or an 11 letter youtube video id.";
    // tags {title}, {errorcode}, {adder} or {user} for the person that added the video
    public string YT_VIDEO_ERROR_MSG = ""; // blank means no message sent
    // tags {user}, {title}
    public string YT_VIDEO_ALREADY_PRESENT_MSG = "@{user} that's already in the playlist : '{title}'";
    // tags {user} message for when !takeover used - set to "" for no message
    public string YT_USER_DENIED_MSG = "Sorry @{user} access denied.";
    // tags {user}, {title} - not yet: {position}.  Set to same thing if you don't want to indicate temp/perm storage
    public string YT_VIDEO_ADD_PERMANENT_MSG = "Adding {title} permanently to the playlist.";
    public string YT_VIDEO_ADD_TEMP_MSG = "Adding {title} temporarily to the playlist.  Thanks, {user}.";

    // number of now and nexts to retrieve, 1 = now playing, 2 = now and next, 3 = now and next 2, etc
    public int YT_NOW_AND_NEXT_COUNT = 5;
    // should now and next results each have a new message
    public bool YT_NOW_AND_NEXT_SEPARATE_MESSAGES = false;
    // Separates songs when now and next list in one message
    public string YT_NOW_AND_NEXT_LIST_SEPARATOR = ", ";
    // Show 1., 2., 3. etc before now and nexts
    public bool YT_NOW_AND_NEXT_SHOW_COUNTER = true;

    public bool YT_LOG_PLAY_FAILS = true;
    // storage location for the permanent playlist
    public string YT_FAILED_VIDEOS_LOGFILE = @"C:\mystuff\Streamerbot-DM\ytplaylists\yt-failed-to-play.txt";

    // used to retrieve video info, setup below, leave blank.
    public string ytAPIUrl;
    // just a test, change the message to check config has updated if you like
    public string TEST_MSG = "Config value safely retrieved.";
}


public class CPHInline
{       // if you don't use "keep active" in streamerbot it'll always rewrite the config.  To be fair who's going to delete it during runtime?  Only me.
    bool initialised = false;

    public bool Execute()
    {   // need persist if wanted
        //if (initialised) {say("Conf initialised, don't need to do again"); return true;}
        setup_and_notify();
        return true;
    }

    // the messages here won't be seen on bot start up
    public void Init()
    {
    	//setup_and_notify();
    }

    public bool setup_and_notify()
    {
        initialised = true;
        YT_Config_Setup();
        CPH.Wait(200);  // maybe the config value takes a while to write
        try // trigger the config grab in MASTER
        {
            bool res = CPH.ExecuteMethod("YTPlayer MASTER Script", "config_ready_callback");
        } catch (Exception e) {
            say("ERROR: Config Init() failed to call Master config_ready()");
        }

        return true;
    }

    // creates the config glass, JSON's it to the non-persisted globals
    public bool YT_Config_Setup()
    {
        try {
            config con = new config();

            con.ytAPIUrl  = $@"https://youtube.googleapis.com/youtube/v3/videos?part=snippet&key={con.apikey}" +
                              @"&fields=items.snippet.title,items.snippet.channelTitle&id=";
            string json = JsonConvert.SerializeObject(con);
            CPH.SetGlobalVar("YT_CONFIG", json, false);
            CPH.SendMessage("Set global YT Config Json length:" + json.Length, true);
        } catch (Exception e) {
            CPH.SendMessage("Config Init Error:" + e.ToString(), true);
            return false;
        }

        return true;
    }

    // shortcut to Twitch message
    public void say(string w2s)
    {
        CPH.SendMessage(w2s, true);
    }
}/*  bool RunAction(string actionName, bool runImmediately = true);
    bool RunActionById(string actionId, bool runImmediately = true);
    bool ExecuteMethod(string executeCode, string methodName); */
