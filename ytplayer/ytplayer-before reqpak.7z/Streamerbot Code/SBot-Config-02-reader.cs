using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

/*
    Reads values from the previously created thingy
    Before this code I could just call a method from the config setup

*/

public class CPHInline
{
    bool configInitialised = false;
    JToken config;

        // I wonder what happens if this returns false when called from a C# method

    public bool Execute()
    {
        test_it();
        // your main code goes here
        return true;
    }

    public void Init()
    {
        say("02 Initiliasing, DOING NOTHING");
        //say("02 Initiliasing, calling 02 update_config()");
    	//update_config();
    }

    int dCount = 0, dLimit = 5;
        // can be called from the Config create code
    public bool update_config() {
        //if (this.configInitialised) return true;
        if (++dCount >= dLimit) {
            return true;
        }

        say("02 update_config() called..." + dCount);

        try {
            string YT_JSON = CPH.GetGlobalVar<string>("CONFIG_TEST", false);

            this.config = JToken.Parse( YT_JSON );

            this.configInitialised = true;

            test_it();
    	} catch(Exception e) {
			CPH.SendMessage("02. Config Reading Error:" + e.ToString(), true);
            say("02. should call create_config() in 01.");

            return false;
    	}

        return true;
    }

	public void test_it() {
        string apikey = cgs("apikey");

        say("API KEY from config is "+apikey);

        say("Test is : " + cgs("test"));

        say("Test int is : " + cgi("testi"));

        say("Test of int as string : " + cgs("testi"));


        try {
            say("Test of string as int : " + cgi("test"));
        }
        catch (Exception e) {
            say("Exception string as int : " + e.ToString());
        }

        say("String is a string of int like '236' : " + cgi("teststrisint"));

        say("***** TESTS ARE DONE *******");
    }

        // Config Get String

    public string cgs(string sname) {

        return (string) this.config[sname];
        return "boo";
    }
        // get in
    public int cgi(string iname) {
        try {
            int ret = (int) this.config[iname];
            return ret;
        }
        catch (Exception e) {
            say("Error config get int : " + e.ToString());
            return -7777777;
        }
        return -222222;
    }
        // get bool
    public bool cgb(string bname) {
        return (bool) this.config[bname];
    }
        // shortcut to Twitch message
    public void say(string w2s) {
        CPH.SendMessage(w2s, true);
    }
}