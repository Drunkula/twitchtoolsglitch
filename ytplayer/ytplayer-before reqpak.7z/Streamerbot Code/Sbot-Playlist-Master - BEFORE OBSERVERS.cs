using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;		// json from web grab
using System.Net.Http;			// web grab
using System.Threading.Tasks;	// web grab
using System.Text.RegularExpressions; // parsing video ids from urls
using System.Collections.Generic;   // Dictionary
using System.IO;    // File. load exists write

/*  FLOW:
    CONFIG Init() and Execute call setup_and_notify()
    MASTER Init() puts CONFIG Execute() into a queue.  If it's already initalised it won't call again.

    CONFIG is called on SB start (and save and compile)
    Conf Init() calls Master grab it callback, sets flag so Execute() doesn't do it twice
*/

public class CPHInline
{
    JToken config;  // filled on init in the config action
    Dictionary<string, VidInfo> playlist = new Dictionary<string, VidInfo>();

    string ytAPIUrl =  "Set in Init";
    string playlistFile, playlistVarName;
    bool storePerm = false;  // NOTE: grabbed from perm global or config if it doesn't exist
    int maxDescLen =  150;  // maximum length to trim descriptions

    public bool Execute() {
        try {
            message_handler();
        }
        catch (Exception e) {
            console_log(e.ToString());
        }
        return true;
    }

        // turn server messages into delightful shenanigans

    public void message_handler() {
        try {
            bool isCmd = (string)args["eventSource"] == "command" || (string)args["eventSource"] == "misc";
            bool isSocketMsg = args["__source"].ToString() == "WebsocketCustomServerMessage";
            //bool isSocketConnect = (string)args["__source"] == "WebsocketCustomServerOpen";
            //bool isSocket = (string)args["eventSource"] == "websocketcustomserver";

            //bool isSceneChange = args["__source"].ToString() == "ObsSceneChanged";
                // scene changes __source == "ObsSceneChanged" or triggerName == "OBS Scene Changed"  eventSource just says obs

//console_log("Is socket:" + isSocket + "  is command: " + isCmd + "  is Scene: " + isSceneChange);

           if (isCmd) {
                string command = (string)args["command"];

                bool rabbleDenied = CPH.GetGlobalVar<bool>("playlistrabbldenied", false);
                bool isBroadcaster = false;

                try {   // have to be strings
                    isBroadcaster = (string)args["broadcastUser"] == (string)args["user"];
                }
                catch (Exception e) {
                    CPH.SendMessage("Error testing for broadcaster");
                }
// CPH.SendMessage($"rabble: {isBroadcaster} - denied: {rabbleDenied}", true);

                switch (command) {
                    case "!nan":
                    case "!nn":
                    case "!nowandnext":
                        request_now_and_next(5);
                        return;

                    case "!song":
                    case "!playing":
                        request_now_and_next(1);
                        return;
                }

        //****************** BROADCASTER ONLY ******************//

                if (isBroadcaster) {
                    switch (command) {
                        case "!storeon":
                        case "!store on":
                            set_store_permanent(true);
                            CPH.SendAction("Storage to permanent playlist is ON", true);
                            return;
                            break;
                        case "!storeoff":
                        case "!store off":
                            set_store_permanent(false);
                            CPH.SendAction("Storage to permanent playlist is OFF", true);
                            return;
                            break;
                        case "!del":    // send delete request to browser - reply has permanent true
                        case "!delvid":
                            send("deletecurrentvideoperm");
                            return;

                        case "!delt":    // send delete request to browser - reply permanent false
                        case "!deltemp":
                            send("deletecurrentvideotemp");
                            return;

                            break;
                    }
                }

                    // commands for all but not if !lockout
                if (rabbleDenied && isBroadcaster == false) {
                    CPH.SendMessage(cgs("YT_USER_DENIED_MSG").Replace("{user}", (string)args["user"]));
                    return;
                }

                switch (command) {
                    case "!add":    // string, permanent, next
                    case "!sr":
                    case "!songrequest":
                        bool addNext = cgb("alwaysAddNext") ? true : false;
                        add_video((string)args["rawInput"], storePerm, addNext);
                        break;
                    case "!addnext":
                    case "!add next":
                        add_video((string)args["rawInput"], storePerm, true);
                        break;
                    case "!addtemp":
                    case "!add temp":
                        add_video((string)args["rawInput"], false, true);
                        break;

                    case "!play":
                        send_action("play"); break;
                    case "!pause":
                        send_action("pause"); break;
                    case "!next":
                        send_action("next"); break;
                    case "!prev":
                        send_action("prev"); break;
                    case "!shuffle":
                        send_action("shuffleall");
                        send_action("next");
                            break;
                    case "!fwd":
                    case "!forward":
                        fwd_rwd(false);
                        break;
                    case "!rwd":
                    case "!rewind":
                        fwd_rwd(true);  // true means rewind
                        break;

                    case "!scount":
                        console_log("Sending playlistcount");
                        send("playlistcount");
                        //CPH.SendMessage("Number of songs in playlist:" + playlist.Count);
                        break;

                    case "!gap":
                        send("getwholeplaylist");
                        break;

                    case "!testconf":
                        say( "Config Test: " + cgs("TEST_MSG") );
                        break;
                }
            }
            else    // Messages FROM THE PLAYER / Observers
                //****************** SOCKET IN MESSAGES *****************//
            if (isSocketMsg) {
                string data = (string) args["data"];
                    // share this string declaration
                string msg;
console_log("data: " + data, "y");

            // is the data json?
                if (data[0] == '{') {
                    JToken js = JToken.Parse(data);
                    //console_log("json action:" + js["action"]);
                    string action = (string)js["action"];
                    switch(action) {
                        case "playlistdeleted": // player got error deleting video and deleted it locally - rename this
                            msg = cgs("YT_VIDEO_ERROR_MSG");
                            msg = msg.Replace("{adder}", (string)js["adder"]).Replace("{user}", (string)js["adder"]).Replace("{errorcode}", (string)js["errorcode"]);
                            msg = msg.Replace("{title}", (string)js["title"]);
                            //$"@{(} Oh noes!  {(string)js["title"]} didn't work.  Sowwweeeee.  NotLikeThis BibleThump BibleThump [code:{(string)js["errorcode"]}]";
                            console_log(msg);
                            CPH.SendMessage(msg);
                            break;

                        case "videodeleted":
                            if ( js["title"] != null) {
                                say( $"Video deleted: \"{js["title"]}\" added by {js["adder"]}" );
                            } else
                                say("Video deleted no idea what it was");

                            if ((bool) js["permanent"] == true) {
                                playlist.Remove( (string) js["id"] );
                                save_playlist();
                            }
                            break;

                        case "nowandnext":
                            show_now_and_next(js);
                            break;

                        case "currsongname":
                            //console_log("NOW PLAYING: " + (string)js["data"]);
                            CPH.SendMessage("NOW PLAYING: " + (string)js["data"]);
                            break;

                        case "currsonginfo":
                            say("Playing: " + (string)js["title"] + $" (added by {js["adder"]}, " +
                                ((int) js["duration"] - (int)js["time"] ) + " seconds left)");
                            break;

                        case "playlistcount":
                            CPH.SendMessage("Got playlist count...", true);
                            msg = $"Number of songs in player: {js["count"]}, in permanent playlist: {playlist.Count}";
                            CPH.SendMessage(msg, true);
                            break;

                        case "getwholeplaylist":
                            send("getwholeplaylist");
                            break;

                        case "allplaylistdata":
                            CPH.SendMessage("Just got a hoooge playlist", true);
                            break;
                    }
                }
                else    // NON JSON socket messages
                switch(data) {
                    case "ping":
                        send("pong");
                        break;

                    case "testaddnext":
                        test_add_next();
                        break;

                    case "testaddrandom":
                        test_add_random_pos();
                        break;

                    case "loadplaylist":
                        load_playlist();
                        send_playlist();
                        break;

                    case "saveplaylist":
                        save_playlist();
                        break;

                    default:
                        console_log("No matching action for " + data);
                        break;
                }
            }
        }
        catch (Exception e) {
            error_out(e);
        }

    }

    public bool send_pause() {
        send_action("pause");
        return true;
    }

    public bool send_play() {
        send_action("play");
        return true;
    }

    public void set_store_permanent(bool setTo) {
        storePerm = setTo;
        CPH.SetGlobalVar("playlistPermanentStore", setTo, true);
    }

        // QUEUE up CONFIG Execute

    public void Init() {
            // pre-empt its readyness
        if (config_ready_callback()) return;
        //*
        try {
            CPH.RunAction("[YTPlayer] MASTER CONFIG", false); // if you make this true : infinite loop
        } catch (Exception e) {
            say("ERROR failed to call method in CONFIG script.");
        } //*/
    }

        // Called by CONFIG Script after it's setup

    public bool config_ready_callback() {
        bool res = config_grab();

        if (!res) {
            say("ERROR MASTER:config_ready.  config_grab returned false.  Unable to load playlist");
            return false;
        }

            // setup those vars

        playlistFile    = cgs("playlistFile");
        playlistVarName = cgs("playlistVarName");

        try {
            ytAPIUrl = cgs("ytAPIUrl");
        }
        catch (Exception e) {// actually init here should call their setup
            say("ytAPIUrl isn't in the config.  Setup probably hasn't been run");
        }

        try {
            storePerm = CPH.GetGlobalVar<bool>("playlistPermanentStore", true);
        }
        catch (Exception e) {
            try {
                storePerm = cgb("permanentAddToPlaylist");
            } catch (Exception e2) {
                say("ERROR: permanentAddToPlaylist not in config.  Setting false.");
                storePerm = false;
            }
        }

        CPH.SendAction("NOTE: Storage to permanent playlist is " + (storePerm ? "ON" : "OFF"), true);

        load_playlist();
        send_playlist();
        playlist_backup();

        say("Looks like we're ready : " + cgs("TEST_MSG"));

        console_log("Playlist Entries: " + playlist.Count, "b");
        say("Playlist Entries: " + playlist.Count);

        return true;
    }

        // reads and parses the config JSON from global non-persisted

    public bool config_grab() {
        say("Master grabbing config...");
        // does the key exist
        string json;
        try {
            json = CPH.GetGlobalVar<string>("YT_CONFIG", false);
            say("Conf JSON safely retrieved string of length: " + json.Length);
        }
        catch (Exception e) {
            say("ERROR: the config string isn't in the table");
            return false;
        }

        try {
            this.config = JToken.Parse( json );
        } catch(Exception e) {
            CPH.SendMessage("PARSE Error on json :" + e.ToString(), true);
            return false;
        }

        return true;
    }


    public void Dispose() {
        save_playlist(); // not until debugged
    }

        // add a video - front facing so can use args[]

    public void add_video(string toParse, bool permanent = true, bool addnext = false) {
        string videoid = yt_parse_id( toParse );
        int timeOffset = yt_parse_time( toParse );
        //console_log( "Parsed: " +  videoid);
//say($"video id {videoid} time {timeOffset}");
            // already in the playlist
            // DEBUG - should ask the player, get if it's there and return currpos and it's position
        if ( playlist.ContainsKey(videoid) ) {
            string msg = cgs("YT_VIDEO_ALREADY_PRESENT_MSG")
                .Replace("{user}", (string)args["user"])
                .Replace("{title}", playlist[videoid].title);
            CPH.SendMessage(msg, true);
            return;
        }

        VidInfoResult v = get_video_info(videoid).Result;

        if (v.success) {
            //string str = $"I WILL ADD {(addnext ? " NEXT " : " Randomly ")}\"{v.title}\" from channel '{v.channel}'";
            string str = permanent ? cgs("YT_VIDEO_ADD_PERMANENT_MSG") : cgs("YT_VIDEO_ADD_TEMP_MSG");
            str = str
                .Replace("{user}", (string)args["user"])
                .Replace("{title}", v.title);
            /*
            $"I WILL ADD {(addnext ? " NEXT " : " Randomly ")}\"{v.title}\"";
            str = permanent ? str + " PERMANENTLY!" : "JUST FOR NOW next " + str;
            str = permanent ? str + " PERMANENTLY!" : "JUST FOR NOW next " + str;
            */
            say(str);
            console_log(str);
                // add it to the dictionary!

            VidInfo vi = v.to_vidinfo();
            vi.adder = (string)args["user"];
            vi.starttime = timeOffset;

            if (permanent) {                //playlist.Add(v.videoid, vi); // sod that, grizzles if duplicate key
                playlist[v.videoid] = vi;
                save_playlist();
            }

            send_playlist_add(vi, addnext);
        } else {
            console_log("That didn't parse!", "r");
			string str = cgs("YT_URL_WRONG_MSG").Replace("{user}", (string)args["user"]);
            CPH.SendMessage(str, true);
        }
    }
        // sends the entire playlist as an array to the client
    public void send_playlist() {
        var jp = new {
            action = "fullplaylist",
            data = playlist.Values,
            addnext = false
        };

        send( JsonConvert.SerializeObject(jp) );
    }

    public void send_playlist_add(VidInfo videoinfo, bool addnext = false) {
        var wsIndex = CPH.GetGlobalVar<Int32>("wssIndex", true);

        var package = new {
            data = videoinfo,
            action = "playlistadd",
            addnext
        };

        //js = JObject.FromObject(bar);
		CPH.WebsocketCustomServerBroadcast(JObject.FromObject(package).ToString(), null, wsIndex);//conNumber);//, connection);
    }

        // saves locally and to a file
    public void save_playlist() {
        string js = JsonConvert.SerializeObject(playlist, Formatting.Indented); // newtonsoft
        try {
            File.WriteAllText(playlistFile, js);
            say("Playlist file saved.");
        } catch (Exception e) {
            say("Playlist file save FAILED: " + e.ToString());
        }
            // no indent version for local storage

        try {
            js = JsonConvert.SerializeObject(playlist);
            CPH.SetGlobalVar(playlistVarName, js, true);
        }
        catch (Exception e) {
            console_log($"Error writing global var {playlistVarName}: ", "y");
            console_log(e.ToString());
        }
    }

    public bool load_playlist_from_file() {
        string json = "{}";

        try {
            //say("Playlist file : " + cgs("playlistFile"));
            if (!File.Exists(cgs("playlistFile"))) {
                console_log("WARNING WARNING : No Playlist exists in either location.", "y");
                return false;
            } else {
                json = File.ReadAllText(cgs("playlistFile"));
                console_log("* * * * SUCCESSFUL LOAD from FILE.", "g");
            }

            playlist = JsonConvert.DeserializeObject<Dictionary<string, VidInfo>>(json);

            return true;
        }
        catch (Exception e) {
            CPH.SendMessage("Error loading/parsing playlist from file: " + e.ToString(), true);
            console_log("ERROR loading/parsing playlist from file: " + e.ToString(), "y");
            return false;
        }
    }

    public bool load_playlist_from_global() {
        string json = "{}";

        string playlistVarName = cgs("playlistVarName");

        try {
            // System.NullReferenceException
            json = CPH.GetGlobalVar<string>(playlistVarName, true);
            console_log("* * * * Local global playlist exists.", "g");
                // Newtonsoft.Json.JsonReaderException
            playlist =  JsonConvert.DeserializeObject<Dictionary<string, VidInfo>>(json);
            return true;
        }
        catch (Exception e) {
            if (e is NullReferenceException) {
                console_log($"ERROR ERROR ERROR No global var ({cgs("playlistVarName")})", "r");
            } else if (e is Newtonsoft.Json.JsonReaderException) {
                console_log($"ERROR ERROR ERROR Json parse error of global var ({cgs("playlistVarName")})", "r");
            } else {
                console_log("Global Var read/parse error of : "  + e.ToString(), "r");
            }
            return false;
        }
    }

    public void load_playlist() {
        if ( cgb("backupsEnabled") && load_playlist_from_file() ) {
        } else
            load_playlist_from_global();
    }// load playlist


        // gets the video info from Google API for a given id

    async public Task<VidInfoResult> get_video_info(string videoid) {
        VidInfoResult vid = new VidInfoResult();
        vid.title = "fail";

        using var client = new HttpClient();

        var response = await client.GetAsync( ytAPIUrl + videoid );

            // If the response is successful, we'll
        if (response.IsSuccessStatusCode)
        {
            var json = await response.Content.ReadAsStringAsync();

            JToken parsed = JToken.Parse(json);
                // you just get empty items back if it's a bad videoid
            try {
                vid.videoid = videoid;
                vid.channel = (string)parsed["items"][0]["snippet"]["channelTitle"];
                vid.title = (string)parsed["items"][0]["snippet"]["title"];
                //vid.description = (string)parsed["items"][0]["snippet"]["description"];

                CPH.SetArgument("videoid", videoid);
                CPH.SetArgument("channel", (string)parsed["items"][0]["snippet"]["channelTitle"]);
                CPH.SetArgument("title", (string)  parsed["items"][0]["snippet"]["title"]);
                    // fucking hell, Substring fails if the last parameter is out of range of the string.  C# is fucking shit.
                /*
                string desc = parsed["items"][0]["snippet"]["description"].ToString();
                if (desc.Length > maxDescLen)
                    desc = desc.Substring(0, maxDescLen) + "...";
                CPH.SetArgument("description", desc);
                */
                vid.success = true;
            } catch(Exception e) {
                // CPH.SendMessage("get_video_info Error: " + e.ToString());
                console_log("Error in getting video info: " + e.ToString(), "r");
            }

            try {
                CPH.SetGlobalVar("vidinfo", json, true);
            }
            catch (Exception e) {
                CPH.SendMessage("Error setting vidinfo global var NoOOoOooOo: " + e.ToString());
                console_log("Error in setting persisted global: " + e.ToString(), "r");
            }
            //
        }

        return vid;
    }

        // extract time in seconds from yt url

    public int yt_parse_time(string toParse) {
        try {
            Match strSec = new Regex(@"(?:[?&]t=)(\d+)").Match(toParse);
                //    say("Found this: value:" + strSec.Value + " 0: " + strSec.Groups[0] + " 1:" + strSec.Groups[1]);
            if (strSec.Success) {
                return int.Parse(strSec.Groups[1].ToString());
            }
        } catch (Exception e) {
            say("Error in parsing time" + e.ToString());
            console_log(e.ToString());
        }

        return 0;
    }

		// extract the 11 character video id from a url or whatever

    public string yt_parse_id(string toParse)
    {
    	try {
            //string url = toParse;//"https://www.youtube.com/watch?v=ISTB0ThzhOY http://www.youtube.com/vi=XXTwATpSvMg?fs=1&hl=en_US&rel=0 http://www.youtube.com/v/0zM3nprIcKg?fs=1&hl=en_US&rel=0";
            const string matchSet = "0-9a-zA-Z_-";
                // YT url regex
            Regex ytid = new Regex(@"(?<=/v/|/e/|\.be/|v=|vi=)["+matchSet+"]{11}");

            if ( toParse.Length < 11) {
                // nothing for now while testing
                return "";
            }
            else {
                if ( toParse.Length == 11) {
                    ytid = new Regex(@"["+matchSet+"]{11}");  // 11 char regex
                }
            }

            Match ym = ytid.Match(toParse);

            if (ym.Success) {
                return ym.ToString();
            } else {
                return "";
            }
            /*
            int count = 0;

            while (ym.Success) {
                CPH.SetArgument( "videoid" + count++.ToString(), ym.Groups[0] );// you can just use ym
                ym = ym.NextMatch();
            } //*/

		}// try
		catch(Exception e) {
			CPH.SendMessage( "Error: " + e.ToString() );

            console_log("Error in yt_parse_id:" + e.ToString());

            return "";
		}
    }

    public void show_now_and_next(JToken js) {
        console_log("You send me now and next stuff");

        int count = (int)js["count"];

        string[] titles = js["titles"].ToObject<string []>();
            // maybe no counter for first
        if ( cgb("YT_NOW_AND_NEXT_SHOW_COUNTER") ) {
            int startCount = 1;

            for (int i = 0; i < titles.Length; i++) {
                titles[i] = (startCount + i) + ": " + titles[i];
            }
        }

        if ( cgb("YT_NOW_AND_NEXT_SEPARATE_MESSAGES") == false ) {
            string allt = string.Join(cgs("YT_NOW_AND_NEXT_LIST_SEPARATOR"), titles);
            console_log("NAN: " + allt, "r");
            CPH.SendMessage("Now and next: " + allt, true);
        } else {
            foreach (string t in titles) {
                CPH.SendMessage(t, true);
            }
        }

    }

        // sends a message action for the client to use console.log()

    public void console_log(string message, string colour = "g") {
        // oh you fool, this creates bad json
        message = JsonConvert.ToString(message);

        string outs = $$"""{"action": "consolelog", "message": {{message}}, "colour": "{{colour}}"}""";

		var wsIndex = CPH.GetGlobalVar<Int32>("wssIndex", true);
		CPH.WebsocketCustomServerBroadcast(outs, null, wsIndex);//conNumber);//, connection);
    }

    public void send(string msg) {
        var wsIndex = CPH.GetGlobalVar<Int32>("wssIndex", true);
		CPH.WebsocketCustomServerBroadcast(msg, null, wsIndex);
    }

    public void send_action(string action, object data = null) {
        var toSend = new {
            action,
            data
        };

        send(JsonConvert.SerializeObject(toSend));
    }

    public void error_out(Exception e) {
        CPH.SendMessage(e.ToString(), true);
        console_log("Error: " + e.ToString());
    }

        // only one backup will be done per day - the trick days % numBackups then set the value in the perm logs

    public void playlist_backup() {
        if (!cgb("backupsEnabled")) return;

        int lastDaySaved = -1;
        int dayNumberNow = (DateTime.Now - new DateTime()).Days % cgi("totalDailyBackups");
        const string backupVarName = "ytplaylist-last-backup-day";

        try {
            lastDaySaved = CPH.GetGlobalVar<int>(backupVarName, true);
        }
        catch (Exception e) {
            // don't do anything
        }
            // get the playlist var
        if (lastDaySaved != dayNumberNow) {
            string js = JsonConvert.SerializeObject(playlist, Formatting.Indented); // newtonsoft
            File.WriteAllText(cgs("playlistFile")+$".backup-{dayNumberNow}.json", js);
            CPH.SetGlobalVar(backupVarName, dayNumberNow, true);
        }
    }

        // callable by Actions - makes scene change stuff easier
    public bool send_play_or_pause() {
        if ( !args.ContainsKey("obsRaw.videoActive") ) return true; // ALWAYS return true so actions can continue

        if ( (bool)args["obsRaw.videoActive"] ) {
            send_action("play");
        } else {
            send_action("pause");
        }

        return true;
    }

    public void fwd_rwd(bool dirIsRwd = false) {
        try {
            int mSecs;
            Int32.TryParse(args["input0"].ToString(), out mSecs);
            mSecs = mSecs == 0 ? 30 : mSecs;
            string action = dirIsRwd ? "rwd" : "fwd";
            send_action(action, mSecs);
        }
        catch (Exception e) {
            console_log("fwd_rwd error: " + e.ToString());
        }
    }

    public void request_now_and_next(int howMany = 1) {
        send_action("nowandnext", new {howMany});
    }

        // **************** DEBUG TESTS IGNORE LATER *******************

    int testAddCounter = 0;

    public void test_add_next() {
		var wsIndex = CPH.GetGlobalVar<Int32>("wssIndex", true);

		JObject js;

		VidInfo data3 = new VidInfo{videoid = $"{testAddCounter} Nxt", title = $"NextYes title {testAddCounter}", adder =$"Mr {testAddCounter++}"};

		var bar = new {
			data = data3,
			action = "playlistadd",
			addnext = true
		};

		js = JObject.FromObject(bar);
		CPH.WebsocketCustomServerBroadcast(js.ToString(), null, wsIndex);//conNumber);//, connection);
    }

    public void test_add_random_pos() {
        console_log("Sending Random fake video id");

		var wsIndex = CPH.GetGlobalVar<Int32>("wssIndex", true);

		string dataS = $"{testAddCounter++} Rnd";
		var foo2 = new {
			data = dataS,
			action = "playlistadd"
		};

		JObject js2 = JObject.FromObject(foo2);
		CPH.WebsocketCustomServerBroadcast(js2.ToString(), null, wsIndex);//conNumber);//, connection);
    }


        // config get string
    public string cgs(string sname) {
        try {
            return (string) this.config[sname];
        }
        catch (Exception e) {
            console_log($"ERROR getting ${sname} string from config: " + e.ToString());
            say($"ERROR getting ${sname} string from config: " + e.ToString());
            return "ERROR_GETTING_CONFIG_STRING";
        }
    }
        // config get int
    public int cgi(string iname) {
        try {
            return (int) this.config[iname];
        }
        catch (Exception e) {
            console_log($"Error config get int {iname} from config: " + e.ToString());
            say($"Error config get int {iname} from config: " + e.ToString());
            return -777777777;
        }
    }
        // config get bool
    public bool cgb(string bname) {
        try {
            return (bool) this.config[bname];
        }
        catch (Exception e) {
            console_log($"ERROR getting {bname} string from config: " + e.ToString());
            say($"ERROR getting {bname} string from config: " + e.ToString());
            return false;
        }
    }
        // shortcut to Twitch message
    public void say(string w2s, bool bot = true) {
        CPH.SendMessage(w2s, bot);
    }
}// CPH ends

    //////////////////////////////////////////////////
    //////////////////// CLASSES /////////////////////
    //////////////////////////////////////////////////

public struct VidInfoResult {
    public string videoid = "fail";
    public string channel = "fail";
    public string title = "fail";
    //public string description;
    //public string adder;
    public bool success = false;    // whether the call was successful

    public VidInfoResult() {
    }

    public VidInfo to_vidinfo() {
        return new VidInfo(videoid, channel, title);
    }
}
    // stripped down version but I might add an offset position
    // playlists are dictionaries of VidInfo
public struct VidInfo {
    public string videoid = "fail";
    public string channel = "fail";
    public string title = "fail";
    public int starttime = 0;
    //public string description;
    public string adder = "fail";
        // do I need this if there's the other one?
    public VidInfo() {
    }

    public VidInfo(string videoid, string channel, string title, string adder="unknown") {
		this.videoid = videoid;
		this.channel = channel;
		this.title = title;
        this.adder = adder;
    }
}

    // Array of observers to receive playlist/playposition/deletes etc basically for the controller page.
class Observer {
    string sessionId = "";
    int wssIndex = 0;
}

/*
    V1.3.0 - config to separate file
    V1.2.0 - Adding multiple playlists

    Flip doesn't want to store user adds to the main playlist so need a playlist switcher
    A user playlist will be created separate from Flip's main one that CAN be stored

    NEED.
        Request playlist by name
        Create playlist(name)
        Switch to change playlists

        Playlists need flags
            shuffle - possibly, client can decide
            store permanent

    FLIPS list starts first every time.  Command switches to the user playlist
    !comps to turn on community playlist
*/


// "Fsy2mZkGm3c"
/*
    As an action triggered by a socket message we will have:
    data, wssIdx (number for broadcast), wssId (ignore), sessionId (single target response), wssName (ws8081)
    eventSource, __source and triggerName/triggerCategory to check if command or socket


{
  "requestType": "GetSourceActive",
  "requestData": {
    "sourceName": "YTPlayer"
  }
}
returns
{
  "videoActive": true,
  "videoShowing": true
}


What happens on close event

Open
__source : WebsocketCustomServerOpen
triggerName : Custom Server Connection Opened
sessionId, wssIdx 0, wssName ws8081, wssId 81a9df21-91cc-45a3-9ea3-7cd6959960ec

Observer/Playlist and Player pages

I could actually just do broadcasts and put
{
    "for": "observer" or "for": "all"
}
*/