using System;
//using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;		// json from web grab
using System.Net.Http;			// web grab
using System.Threading.Tasks;	// web grab
using System.Text.RegularExpressions; // parsing video ids from urls
using System.Collections.Generic;   // Dictionary
using System.IO;    // File. load exists write

/*  FLOW:
    CONFIG Init() and Execute call setup_and_notify()
    MASTER Init() puts CONFIG Execute() into a queue.  If it's already initalised it won't call again.

    CONFIG is called on SB start (and save and compile)
    Conf Init() calls Master grab it callback, sets flag so Execute() doesn't do it twice

    wssIdx: index in socket table CRITICAL, wssName: name in the socket table,
    wssId: id of the connecting socket.  Save to observer or player

    IDEA - players have an ID and send it with every request.  If they don't have
    an id one is assigned to them based on their sessionId.
    The ID can be in the query params and that'll let us have separate playlists
    for each one, or the generic one otherwise.
*/

public class CPHInline
{
    const string SOCKET_NAME = "YTPlayer";  // Streamerbot socket name
    int wssIndex = 0;   // set in Init() using name above

    JToken config;  // filled on init in the config action
    Dictionary<string, VidInfo> playlist = new Dictionary<string, VidInfo>();
        // Players with the same name will have digits added
    int playerNameCounter = 2;
    int observerNameCounter = 2;
    // players <UID, sessionId> sockets sends its UID after connect
    Dictionary<string, YTSock> players     = new Dictionary<string, YTSock>();
    Dictionary<string, YTSock> observers   = new Dictionary<string, YTSock>();
        //
    string ytAPIUrl =  "Set in Init";
    string playlistFile, playlistVarName;
    bool storePerm = false;  // NOTE: grabbed from perm global or config if it doesn't exist
    int maxDescLen =  150;  // maximum length to trim descriptions

    int sockNameCount = 1;  // if a connection's name is already in the list add a number

    public bool Execute() {
        try {
            message_handler();
        }
        catch (Exception e) {
            console_log(e.ToString());
        }
        return true;
    }

        // turn server messages into delightful shenanigans

    public void message_handler() {
        try {
            bool isCmd        = args["eventSource"].ToString() == "command" || args["eventSource"].ToString() == "misc";
            bool isSocketMsg  = args["__source"].ToString() == "WebsocketCustomServerMessage";
            bool isConnect    = args["__source"].ToString() == "WebsocketCustomServerOpen";
            bool isDisconnect = args["__source"].ToString() == "WebsocketCustomServerClose";// presuming, never seen
            //bool isSceneChange = args["__source"].ToString() == "ObsSceneChanged";
                // scene changes __source == "ObsSceneChanged" or triggerName == "OBS Scene Changed"  eventSource just says obs

try {   // messages to non-existent sockets do nothing
    CPH.WebsocketCustomServerBroadcast("PIS PIS PIS", "foioaio", wssIndex);
} catch (Exception e) {
    say("Socket send not work: " + e.ToString());
}
//console_log("Is socket:" + isSocket + "  is command: " + isCmd + "  is Scene: " + isSceneChange);

                //****************** SOCKET IN MESSAGES *****************//
            if (isSocketMsg) {
                string socketId = args["sessionId"].ToString(); // id of the calling socket
                string data = (string) args["data"];
                    // share this string declaration
                string msg;
//console_log("data: " + data, "y");

            // is the data json?
                if (data[0] == '{') {
                    JToken js = JToken.Parse(data);
                    //console_log("json action:" + js["action"]);
                    string action = (string)js["action"];
                    switch(action) {
                        case "playlistdeleted": // player got error deleting video and deleted it locally - rename this
                            msg = cgs("YT_VIDEO_ERROR_MSG");
                            msg = msg.Replace("{adder}", (string)js["adder"]).Replace("{user}", (string)js["adder"]).Replace("{errorcode}", (string)js["errorcode"]);
                            msg = msg.Replace("{title}", (string)js["title"]);
                            //$"@{(} Oh noes!  {(string)js["title"]} didn't work.  Sowwweeeee.  NotLikeThis BibleThump BibleThump [code:{(string)js["errorcode"]}]";
                            console_log(msg);
                            CPH.SendMessage(msg);
                            break;

                        case "videoerror":
                            if ( js["title"] != null) {
                                say( $"Video deleted: \"{js["title"]}\" added by {js["adder"]}" );
                            } else
                                say("Video deleted no idea what it was");

                            log_video_error((string)js["videoid"], (string)js["title"], (string)js["adder"], (string)js["errorcode"]);
                            // jTokens will return null if the value isn't present
                            bool? permRemove = (bool?)js["permanent"];
                            if (permRemove  == true) {
                                playlist.Remove( (string) js["id"] );
                                save_playlist();
                            }
                            break;

                        case "nowandnext":
                            show_now_and_next(js);
                            break;

                        case "currsongname":
                            //console_log("NOW PLAYING: " + (string)js["data"]);
                            CPH.SendMessage("NOW PLAYING: " + (string)js["data"]);
                            break;

                        case "currsonginfo":
                            say("Playing: " + (string)js["title"] + $" (added by {js["adder"]}, " +
                                ((int) js["duration"] - (int)js["time"] ) + " seconds left)");
                            break;

                        case "playlistcount":
                            CPH.SendMessage("Got playlist count...", true);
                            msg = $"Number of songs in player: {js["count"]}, in permanent playlist: {playlist.Count}";
                            CPH.SendMessage(msg, true);
                            break;

                        case "getwholeplaylist":
                            send("getwholeplaylist", socketId);
                            break;
                            // proof of concept of revivifying things from json
                        case "allplaylistdata":
                            /*
                            string[] pc = js["data"]["playlist"].ToObject<string[]>();
							int pCount = pc.Length;
                            msg = "";
                            if (pCount > 0) {
                                int index = (int)js["data"]["playlistindex"];
                                string songid = pc[index];
                                var pmap = js["data"]["playlistmap"].ToObject<Dictionary<string, VidInfo>>();
                                msg = $" at position {index} with {pmap[songid].title} added by {pmap[songid].adder}";
                            }
                            say("Just got a hoooge playlist : " + pCount + msg, true);
                            */
                            send_action("allplaylistdata", data, "observers");
                            break;

                            case "iAmAnObserver":// players send id on reconnects
                                {   // brackets for variable scope
                                string id = (string)js["id"];   // uid
                                string name = (string)js["name"];
                                bool nameChangeRqd = false; // is a name increase required
                                YTSock yt = new YTSock(id, name);
                                    // is the observer already in there
                                foreach(KeyValuePair<string, YTSock> entry in observers)
                                {
                                    if (entry.Value.UID == id) {
                                        yt.name = entry.Value.name;
                                        observers.Remove(entry.Key);
                                    } else if (entry.Value.name == name) {
                                        nameChangeRqd = true;
                                    }
                                }
                                if (nameChangeRqd) {
                                    name = name + $" {observerNameCounter++}";
                                    yt.name = name;
                                    send_json(new {action = "namechange", name}, socketId);
                                }

                                this.observers[socketId] = yt;
                                console_log($"You're a observer, sweetheart.  Noted.  name: {name}, session id: {socketId}, your id {id}, players: {players.Count}, observers: {observers.Count}", "g", socketId);
                                }
                                break;

                            case "iAmAPlayer":// players should sent an assigned id on reconnects
                                {
                                string id = (string)js["id"];
                                string name = (string)js["name"];
                                bool nameChangeRqd = false; // is a name increase required
                                    // is the player already in there
                                YTSock yt = new YTSock(id, name);
                                foreach(KeyValuePair<string, YTSock> entry in players)
                                {
                                    if (entry.Value.UID == id) {
                                        yt.name = entry.Value.name;
                                        players.Remove(entry.Key);
                                    } else if (entry.Value.name == name) {
                                        nameChangeRqd = true;
                                    }
                                }
                                if (nameChangeRqd) {
                                    name = name + $" {playerNameCounter++}";
                                    yt.name = name;
                                    send_json(new {action = "namechange", name}, socketId);
                                }
                                this.players[socketId] = yt;
                                console_log($"You're a PLAYER, SON! name: {name}, session id: {socketId}, your id {id}, players: {players.Count}, observers: {observers.Count}", "g", socketId);
                                }
                                break;

                            default:
                                console_log("No matching JSON action for " + action);
                                break;
                    }
                }
                else    // NON JSON socket messages
                switch(data) {
                    case "ping":
                        send("pong", socketId); break;
                    case "closing":
                        players.Remove(socketId);
                        observers.Remove(socketId);
                        /*
                        foreach(KeyValuePair<string, YTSock> entry in players) {
                            if (entry.Value == socketId) players.Remove(entry.Key);
                        }
                        foreach(KeyValuePair<string, YTSock> entry in observers) {
                            if (entry.Value == socketId) observers.Remove(entry.Key);
                        }*/
                        break;

                    case "testaddnext":
                        test_add_next(socketId); break;
                    case "testaddrandom":
                        test_add_random_pos(socketId); break;
                    case "loadplaylist":
                        load_playlist();
                        send_playlist(socketId); break; // targetted

                    case "saveplaylist":
                        save_playlist(); break;
                    case "playnext":
                        send_action("next", null, "players"); break;
                    case "playprev":
                        send_action("prev"); break;
                    case "play":
                        send_action("play"); break;
                    case "pause":
                        send_action("pause"); break;
                    case "getwholeplaylist":
                        send("getwholeplaylist"); break;

                    case "iAmAPlayer":// if a player has previously had an id it should send it on reconnect
                        console_log("You're a player are you, luv.", "y", socketId);
                        break;

                    default:
                        console_log("No matching action for " + data);
                        break;
                }
            } else
    /// ************* TWITCH COMMANDS ************ ///
            if (isCmd) {
                string command = (string)args["command"];

                bool rabbleDenied = CPH.GetGlobalVar<bool>("playlistrabbldenied", false);
                bool isBroadcaster = false;

                try {   // have to be strings
                    isBroadcaster = (string)args["broadcastUser"] == (string)args["user"];
                }
                catch (Exception e) {
                    CPH.SendMessage("Error testing for broadcaster");
                }
// CPH.SendMessage($"rabble: {isBroadcaster} - denied: {rabbleDenied}", true);

                switch (command) {
                    case "!nan":
                    case "!nn":
                    case "!nowandnext":
                        request_now_and_next(5);
                        return;

                    case "!song":
                    case "!playing":
                        request_now_and_next(1);
                        return;
                }

        //****************** BROADCASTER ONLY ******************//

                if (isBroadcaster) {
                    switch (command) {
                        case "!storeon":
                        case "!store on":
                            set_store_permanent(true);
                            CPH.SendAction("Storage to permanent playlist is ON", true);
                            return;
                            break;
                        case "!storeoff":
                        case "!store off":
                            set_store_permanent(false);
                            CPH.SendAction("Storage to permanent playlist is OFF", true);
                            return;
                            break;
                        case "!del":    // send delete request to browser - reply has permanent true
                        case "!delvid":
                            send("deletecurrentvideoperm");
                            return;

                        case "!delt":    // send delete request to browser - reply permanent false
                        case "!deltemp":
                            send("deletecurrentvideotemp");
                            return;

                            break;
                    }
                }

                    // commands for all but not if !lockout
                if (rabbleDenied && isBroadcaster == false) {
                    CPH.SendMessage(cgs("YT_USER_DENIED_MSG").Replace("{user}", (string)args["user"]));
                    return;
                }

                switch (command) {
                    case "!add":    // string, permanent, next
                    case "!sr":
                    case "!songrequest":
                        bool addNext = cgb("alwaysAddNext") == true ? true : false;
                        add_video((string)args["rawInput"], storePerm, addNext);
                        break;
                    case "!addnext":
                    case "!add next":
                        add_video((string)args["rawInput"], storePerm, true);
                        break;
                    case "!addtemp":
                    case "!add temp":
                        add_video((string)args["rawInput"], false, true);
                        break;

                    case "!play":
                        send_action("play"); break;
                    case "!pause":
                        send_action("pause"); break;
                    case "!next":
                        send_action("next"); break;
                    case "!prev":
                        send_action("prev"); break;
                    case "!shuffle":
                        send_action("shuffleall");
                        send_action("next");
                            break;
                    case "!fwd":
                    case "!forward":
                        fwd_rwd(false);
                        break;
                    case "!rwd":
                    case "!rewind":
                        fwd_rwd(true);  // true means rewind
                        break;

                    case "!scount":
                        console_log("Sending playlistcount");
                        send("playlistcount");
                        //CPH.SendMessage("Number of songs in playlist:" + playlist.Count);
                        break;

                    case "!gap":
                        send("getwholeplaylist");
                        break;

                    case "!testconf":
                        say( "Config Test: " + cgs("TEST_MSG") );
                        break;
                }
            }
        }
        catch (Exception e) {
            error_out(e);
        }

    }

    public bool send_pause() {
        send_action("pause");
        return true;
    }

    public bool send_play() {
        send_action("play");
        return true;
    }

    public void set_store_permanent(bool setTo) {
        storePerm = setTo;
        CPH.SetGlobalVar("playlistPermanentStore", setTo, true);
    }

        // QUEUE up CONFIG Execute

    public void Init() {
        wssIndex = CPH.WebsocketCustomServerGetConnectionByName(SOCKET_NAME);
            // pre-empt its readyness
        if (config_ready_callback()) return;
        //*
        try {
            CPH.RunAction("[YTPlayer] MASTER CONFIG", false); // if you make this true : infinite loop
        } catch (Exception e) {
            say("ERROR failed to call method in CONFIG script.");
        } //*/
    }

        // Called by CONFIG Script after it's setup

    public bool config_ready_callback() {
        bool res = config_grab();

        if (!res) {
            say("ERROR MASTER:config_ready.  config_grab returned false.  Unable to load playlist");
            return false;
        }

            // setup those vars

        playlistFile    = cgs("playlistFile");
        playlistVarName = cgs("playlistVarName");

        try {
            ytAPIUrl = cgs("ytAPIUrl");
        }
        catch (Exception e) {// actually init here should call their setup
            say("ytAPIUrl isn't in the config.  Setup probably hasn't been run");
        }

        try {
            storePerm = CPH.GetGlobalVar<bool>("playlistPermanentStore", true);
        }
        catch (Exception e) {
            try {
                storePerm = cgb("permanentAddToPlaylist") == true ? true : false;
            } catch (Exception e2) {
                say("ERROR: permanentAddToPlaylist not in config.  Setting false.");
                storePerm = false;
            }
        }

        CPH.SendAction("NOTE: Storage to permanent playlist is " + (storePerm ? "ON" : "OFF"), true);

        load_playlist();
        send_playlist();    // more like broadcast playlist
        playlist_backup();

        say("Looks like we're ready : " + cgs("TEST_MSG"));

        console_log("Playlist Entries: " + playlist.Count, "b");
        say("Playlist Entries: " + playlist.Count);

        return true;
    }

        // reads and parses the config JSON from global non-persisted

    public bool config_grab() {
        say("Master grabbing config...");
        // does the key exist
        string json;
        try {
            json = CPH.GetGlobalVar<string>("YT_CONFIG", false);
            say("Conf JSON safely retrieved string of length: " + json.Length);
        }
        catch (Exception e) {
            say("ERROR: the config string isn't in the table");
            return false;
        }

        try {
            this.config = JToken.Parse( json );
        } catch(Exception e) {
            CPH.SendMessage("PARSE Error on json :" + e.ToString(), true);
            return false;
        }

        return true;
    }


    public void Dispose() {
        //save_playlist(); // not until debugged
    }

        // add a video - front facing so can use args[]

    public void add_video(string toParse, bool permanent = true, bool addnext = false) {
        string videoid = yt_parse_id( toParse );
        int timeOffset = yt_parse_time( toParse );
            // already in the playlist
            // DEBUG - should ask the player, get if it's there and return currpos and its position
        if ( playlist.ContainsKey(videoid) ) {
            string msg = cgs("YT_VIDEO_ALREADY_PRESENT_MSG")
                .Replace("{user}", (string)args["user"])
                .Replace("{title}", playlist[videoid].title);
            say(msg, true);
            return;
        }

        VidInfoResult v = get_video_info(videoid).Result;

        if (v.success) {
            //string str = $"I WILL ADD {(addnext ? " NEXT " : " Randomly ")}\"{v.title}\" from channel '{v.channel}'";
            string str = permanent ? cgs("YT_VIDEO_ADD_PERMANENT_MSG") : cgs("YT_VIDEO_ADD_TEMP_MSG");
            str = str
                .Replace("{user}", (string)args["user"])
                .Replace("{title}", v.title);
            /*
            $"I WILL ADD {(addnext ? " NEXT " : " Randomly ")}\"{v.title}\"";
            str = permanent ? str + " PERMANENTLY!" : "JUST FOR NOW next " + str;
            str = permanent ? str + " PERMANENTLY!" : "JUST FOR NOW next " + str;
            */
            say(str);
            console_log(str);
                // add it to the dictionary!

            VidInfo vi = v.to_vidinfo();
            vi.adder = (string)args["user"];
            vi.starttime = timeOffset;

            if (permanent) {                //playlist.Add(v.videoid, vi); // sod that, grizzles if duplicate key
                playlist[v.videoid] = vi;
                save_playlist();
            }

            send_playlist_add(vi, addnext);
        } else {
            console_log("That didn't parse!", "r");
			string str = cgs("YT_URL_WRONG_MSG").Replace("{user}", (string)args["user"]);
            CPH.SendMessage(str, true);
        }
    }
        // sends the entire playlist as an array to the client
    public void send_playlist(string? sessionId = null) {
        var jp = new {
            action = "fullplaylist",
            data = playlist.Values,
            addnext = false
        };
//console_log("Sending playlist on " + sessionId);
        send( JsonConvert.SerializeObject(jp), sessionId );
    }

    public void send_playlist_add(VidInfo videoinfo, bool addnext = false) {
        //var wsIndex = CPH.GetGlobalVar<Int32>("wssIndex", true);

        var package = new {
            data = videoinfo,
            action = "playlistadd",
            addnext
        };

        //js = JObject.FromObject(bar);
	//	CPH.WebsocketCustomServerBroadcast(JObject.FromObject(package).ToString(), null, wssIndex);//conNumber);//, connection);
        send(JObject.FromObject(package).ToString());
    }

        // saves locally and to a file
    public void save_playlist() {
        string js = JsonConvert.SerializeObject(playlist, Formatting.Indented); // newtonsoft
        try {
            File.WriteAllText(playlistFile, js);
            say("Playlist file saved.");
        } catch (Exception e) {
            say("Playlist file save FAILED: " + e.ToString());
        }
            // no indent version for local storage

        try {
            js = JsonConvert.SerializeObject(playlist);
            CPH.SetGlobalVar(playlistVarName, js, true);
        }
        catch (Exception e) {
            console_log($"Error writing global var {playlistVarName}: ", "y");
            console_log(e.ToString());
        }
    }

    public bool load_playlist_from_file() {
        string json = "{}";

        try {
            //say("Playlist file : " + cgs("playlistFile"));
            if (!File.Exists(cgs("playlistFile"))) {
                console_log("WARNING WARNING : No Playlist exists in either location.", "y");
                return false;
            } else {
                json = File.ReadAllText(cgs("playlistFile"));
                console_log("* * * * SUCCESSFUL LOAD from FILE.", "g");
            }

            playlist = JsonConvert.DeserializeObject<Dictionary<string, VidInfo>>(json);

            return true;
        }
        catch (Exception e) {
            CPH.SendMessage("Error loading/parsing playlist from file: " + e.ToString(), true);
            console_log("ERROR loading/parsing playlist from file: " + e.ToString(), "y");
            return false;
        }
    }

    public bool load_playlist_from_global() {
        string json = "{}";

        string playlistVarName = cgs("playlistVarName");

        try {
            // System.NullReferenceException
            json = CPH.GetGlobalVar<string>(playlistVarName, true);
            console_log("* * * * Local global playlist exists.", "g");
                // Newtonsoft.Json.JsonReaderException
            playlist =  JsonConvert.DeserializeObject<Dictionary<string, VidInfo>>(json);
            return true;
        }
        catch (Exception e) {
            if (e is NullReferenceException) {
                console_log($"ERROR ERROR ERROR No global var ({cgs("playlistVarName")})", "r");
            } else if (e is Newtonsoft.Json.JsonReaderException) {
                console_log($"ERROR ERROR ERROR Json parse error of global var ({cgs("playlistVarName")})", "r");
            } else {
                console_log("Global Var read/parse error of : "  + e.ToString(), "r");
            }
            return false;
        }
    }

    public void load_playlist() {
        bool backup = cgb("backupsEnabled") == true ? true : false;
        if ( backup && load_playlist_from_file() ) {
        } else
            load_playlist_from_global();
    }// load playlist


        // gets the video info from Google API for a given id

    async public Task<VidInfoResult> get_video_info(string videoid) {
        VidInfoResult vid = new VidInfoResult();
        vid.title = "fail";

        using var client = new HttpClient();

        var response = await client.GetAsync( ytAPIUrl + videoid );

            // If the response is successful, we'll
        if (response.IsSuccessStatusCode)
        {
            var json = await response.Content.ReadAsStringAsync();

            JToken parsed = JToken.Parse(json);
                // you just get empty items back if it's a bad videoid
            try {
                vid.videoid = videoid;
                vid.channel = (string)parsed["items"][0]["snippet"]["channelTitle"];
                vid.title = (string)parsed["items"][0]["snippet"]["title"];
                //vid.description = (string)parsed["items"][0]["snippet"]["description"];

                CPH.SetArgument("videoid", videoid);
                CPH.SetArgument("channel", (string)parsed["items"][0]["snippet"]["channelTitle"]);
                CPH.SetArgument("title", (string)  parsed["items"][0]["snippet"]["title"]);
                    // fucking hell, Substring fails if the last parameter is out of range of the string.  C# is fucking shit.
                /*
                string desc = parsed["items"][0]["snippet"]["description"].ToString();
                if (desc.Length > maxDescLen)
                    desc = desc.Substring(0, maxDescLen) + "...";
                CPH.SetArgument("description", desc);
                */
                vid.success = true;
            } catch(Exception e) {
                // CPH.SendMessage("get_video_info Error: " + e.ToString());
                console_log("Error in getting video info: " + e.ToString(), "r");
            }

            try {
                CPH.SetGlobalVar("vidinfo", json, true);
            }
            catch (Exception e) {
                CPH.SendMessage("Error setting vidinfo global var NoOOoOooOo: " + e.ToString());
                console_log("Error in setting persisted global: " + e.ToString(), "r");
            }
            //
        }

        return vid;
    }

        // extract time in seconds from yt url

    public int yt_parse_time(string toParse) {
        try {
            Match strSec = new Regex(@"(?:[?&]t=)(\d+)").Match(toParse);
                //    say("Found this: value:" + strSec.Value + " 0: " + strSec.Groups[0] + " 1:" + strSec.Groups[1]);
            if (strSec.Success) {
                return int.Parse(strSec.Groups[1].ToString());
            }
        } catch (Exception e) {
            say("Error in parsing time" + e.ToString());
            console_log(e.ToString());
        }

        return 0;
    }

		// extract the 11 character video id from a url or whatever

    public string yt_parse_id(string toParse)
    {
    	try {
            //string url = toParse;//"https://www.youtube.com/watch?v=ISTB0ThzhOY http://www.youtube.com/vi=XXTwATpSvMg?fs=1&hl=en_US&rel=0 http://www.youtube.com/v/0zM3nprIcKg?fs=1&hl=en_US&rel=0";
            const string matchSet = "0-9a-zA-Z_-";
                // YT url regex
            Regex ytid = new Regex(@"(?<=/v/|/e/|\.be/|v=|vi=)["+matchSet+"]{11}");

            if ( toParse.Length < 11) {
                // nothing for now while testing
                return "";
            }
            else {
                if ( toParse.Length == 11) {
                    ytid = new Regex(@"["+matchSet+"]{11}");  // 11 char regex
                }
            }

            Match ym = ytid.Match(toParse);

            if (ym.Success) {
                return ym.ToString();
            } else {
                return "";
            }
            /*
            int count = 0;

            while (ym.Success) {
                CPH.SetArgument( "videoid" + count++.ToString(), ym.Groups[0] );// you can just use ym
                ym = ym.NextMatch();
            } //*/

		}// try
		catch(Exception e) {
			CPH.SendMessage( "Error: " + e.ToString() );

            console_log("Error in yt_parse_id:" + e.ToString());

            return "";
		}
    }

        // Message of n now and nexts in the playlist

    public void show_now_and_next(JToken js) {
        console_log("You send me now and next stuff");

        int count = (int)js["count"];

        string[] titles = js["titles"].ToObject<string []>();
            // maybe no counter for first
        if ( cgb("YT_NOW_AND_NEXT_SHOW_COUNTER") == false ? false : true ) {
            int startCount = 1;

            for (int i = 0; i < titles.Length; i++) {
                titles[i] = (startCount + i) + ": " + titles[i];
            }
        }

        if ( cgb("YT_NOW_AND_NEXT_SEPARATE_MESSAGES") == false ) {
            string allTitles = string.Join(cgs("YT_NOW_AND_NEXT_LIST_SEPARATOR"), titles);
            console_log("NAN: " + allTitles, "r");
            CPH.SendMessage("Now and next: " + allTitles, true);
        } else {
            foreach (string t in titles) {
                CPH.SendMessage(t, true);
            }
        }
    }

        // sends a message action for the client to use console.log()

    public void console_log(string message, string colour = "g", string? socketId = null) {
        // oh you fool, this creates bad json
        message = JsonConvert.ToString(message);
        string outs = $$"""{"action": "consolelog", "message": {{message}}, "colour": "{{colour}}"}""";
        send(outs, socketId);
    }

        // sockedId can also be "players" or "observers"

    public void send(string msg, string? socketId = null) {
        //var wsIndex = CPH.GetGlobalVar<Int32>("wssIndex", true);
        string[] socks = {socketId};
        switch(socketId) {
            case "observers":
                socks = new string[observers.Keys.Count];
                observers.Keys.CopyTo(socks, 0);
                //console_log("to observers " + String.Join(", ", socks));
                break;
            case "players":
                socks = new string[players.Keys.Count];
                players.Keys.CopyTo(socks, 0);
                //console_log("to players " + String.Join(", ", socks));
                break;
            //case default: socks = [socketId]; break;
        }

        foreach (string sock in socks)
		    CPH.WebsocketCustomServerBroadcast(msg, sock, wssIndex);
    }

    public void send_action(string action, object data = null, string? socketId = null) {
        var toSend = new {
            action,
            data
        };

        send_json(toSend, socketId);
    }

    public void send_json(object o, string? socketId = null) {
        send(JsonConvert.SerializeObject(o), socketId);
    }

    public void error_out(Exception e) {
        CPH.SendMessage("Error Out: " + e.ToString(), true);
        console_log("Error Out: " + e.ToString());
    }

        // only one backup will be done per day - the trick days % numBackups then set the value in the perm logs

    public void playlist_backup() {
        if (cgb("backupsEnabled") != true || cgi("totalDailyBackups") == null) return;

        int numDailyBackups = cgi("totalDailyBackups") ?? 100;

        int lastDaySaved = -1;
        int dayNumberNow = (DateTime.Now - new DateTime()).Days % numDailyBackups;
        const string backupVarName = "ytplaylist-last-backup-day";

        try {
            lastDaySaved = CPH.GetGlobalVar<int>(backupVarName, true);
        }
        catch (Exception e) {
            // don't do anything
        }
            // get the playlist var
        if (lastDaySaved != dayNumberNow) {
            string js = JsonConvert.SerializeObject(playlist, Formatting.Indented); // newtonsoft
            File.WriteAllText(cgs("playlistFile")+$".backup-{dayNumberNow}.json", js);
            CPH.SetGlobalVar(backupVarName, dayNumberNow, true);
        }
    }

        // callable by Actions - makes scene change stuff easier
    public bool send_play_or_pause() {
        if ( !args.ContainsKey("obsRaw.videoActive") ) return true; // ALWAYS return true so actions can continue

        if ( (bool)args["obsRaw.videoActive"] ) {
            send_action("play");
        } else {
            send_action("pause");
        }

        return true;
    }

    public void fwd_rwd(bool dirIsRwd = false) {
        try {
            int mSecs;
            Int32.TryParse(args["input0"].ToString(), out mSecs);
            mSecs = mSecs == 0 ? 30 : mSecs;
            string action = dirIsRwd ? "rwd" : "fwd";
            send_action(action, mSecs);
        }
        catch (Exception e) {
            console_log("fwd_rwd error: " + e.ToString());
        }
    }

    public void request_now_and_next(int howMany = 1) {
        send_action("nowandnext", new {howMany});
    }


        /// ************** CONFIG HELPERS ********************* ///
        /// jTokens return null if the value doesn't exist
        /// I could flag an error if the value doesn't exist or just return the null

        // config get string
//*
    public string? cgs(string sname) {
        try {
            return (string) this.config[sname]; // could just return string? and it'd always work
        }
        catch (Exception e) {
            console_log($"ERROR getting ${sname} string from config: " + e.ToString());
            say($"ERROR getting ${sname} string from config: " + e.ToString());
            return null;
        }
    } //*/

        // config get int
    public int? cgi(string iname) {
        try {
            return (int) this.config[iname];
        }
        catch (Exception e) {
            console_log($"Error config get int {iname} from config: " + e.ToString());
            say($"Error config get int {iname} from config: " + e.ToString());
            return null;
        }
    }
        // config get bool
    public bool? cgb(string bname) {
        try {
            return (bool) this.config[bname];
        }
        catch (Exception e) {
            console_log($"ERROR getting {bname} string from config: " + e.ToString());
            say($"ERROR getting {bname} string from config: " + e.ToString());
            return null;
        }
    }
        // shortcut to Twitch message
    public void say(string w2s, bool bot = true) {
        CPH.SendMessage(w2s, bot);
    }

        // log video errors to a text file - SHOULD check that they're actually in the perm playlist

    public void log_video_error(string videoid, string title, string adder, string errorcode)
    {       // don't log if they're not permanently stored
        if (!playlist.ContainsKey(videoid) ) return;

        string? logFile = cgs("YT_FAILED_VIDEOS_LOGFILE");
                    //console_log("YT play error log file: " + logFile);
        if (cgb("YT_LOG_PLAY_FAILS") != true) return;
        if (logFile == null) {
            say("Youtube play fail log file \"YT_LOG_PLAY_FAILS\" is not set in the config action");
            return;
        }

            // don't log it if the video id is already present
        if (File.Exists(logFile)) foreach (string line in File.ReadLines(logFile)) {
            if (line.Contains(videoid)) {
                return;
            }
        }

        string logLine = $"Error: {errorcode} : {title}, [{videoid}], adder: {adder}" + Environment.NewLine;
        File.AppendAllText(logFile, logLine);
    }

        // **************** DEBUG TESTS IGNORE LATER *******************

    int testAddCounter = 0;

    public void test_add_next(string socketId) {
		JObject js;

		VidInfo data3 = new VidInfo{videoid = $"{testAddCounter} Nxt", title = $"NextYes title {testAddCounter}", adder =$"Mr {testAddCounter++}"};

		var bar = new {
			data = data3,
			action = "playlistadd",
			addnext = true
		};

		js = JObject.FromObject(bar);
        send(js.ToString(), socketId);
		//CPH.WebsocketCustomServerBroadcast(js.ToString(), null, wssIndex);//conNumber);//, connection);
    }

    public void test_add_random_pos(string socketId) {
        console_log("Sending Random fake video id");

		string dataS = $"{testAddCounter++} Rnd";
		var foo2 = new {
			data = dataS,
			action = "playlistadd"
		};

		JObject js2 = JObject.FromObject(foo2);
		send(js2.ToString(), socketId);
		CPH.WebsocketCustomServerBroadcast(js2.ToString(), null, wssIndex);//conNumber);//, connection);
    }

}// CPH ends

    //////////////////////////////////////////////////
    //////////////////// CLASSES /////////////////////
    //////////////////////////////////////////////////

public struct VidInfoResult {
    public string videoid = "fail";
    public string channel = "fail";
    public string title = "fail";
    //public string description;
    //public string adder;
    public bool success = false;    // whether the call was successful

    public VidInfoResult() {
    }

    public VidInfo to_vidinfo() {
        return new VidInfo(videoid, channel, title);
    }
}
    // stripped down version but I might add an offset position
    // playlists are dictionaries of VidInfo
public struct VidInfo {
    public string videoid = "fail";
    public string channel = "fail";
    public string title = "fail";
    public int starttime = 0;
    //public string description;
    public string adder = "fail";
        // do I need this if there's the other one?
    public VidInfo() {
    }

    public VidInfo(string videoid, string channel, string title, string adder="unknown") {
		this.videoid = videoid;
		this.channel = channel;
		this.title = title;
        this.adder = adder;
    }
}

    // Array of observers to receive playlist/playposition/deletes etc basically for the controller page.
struct YTSock {
    public string UID;
    public string name;

    public YTSock(string u, string name) {
        this.UID = u;
        this.name = name;
    }
}

/*
    V1.3.0 - config to separate file
    V1.2.0 - Adding multiple playlists

    Flip doesn't want to store user adds to the main playlist so need a playlist switcher
    A user playlist will be created separate from Flip's main one that CAN be stored

    NEED.
        Request playlist by name
        Create playlist(name)
        Switch to change playlists

        Playlists need flags
            shuffle - possibly, client can decide
            store permanent

    FLIPS list starts first every time.  Command switches to the user playlist
    !comps to turn on community playlist
*/


// "Fsy2mZkGm3c"
/*
    As an action triggered by a socket message we will have:
    data, wssIdx (number for broadcast), wssId (ignore), sessionId (single target response), wssName (ws8081)
    eventSource, __source and triggerName/triggerCategory to check if command or socket


{
  "requestType": "GetSourceActive",
  "requestData": {
    "sourceName": "YTPlayer"
  }
}
returns
{
  "videoActive": true,
  "videoShowing": true
}


What happens on close event

Open
__source : WebsocketCustomServerOpen
triggerName : Custom Server Connection Opened
sessionId, wssIdx 0, wssName ws8081, wssId 81a9df21-91cc-45a3-9ea3-7cd6959960ec

Observer/Playlist and Player pages

I could actually just do broadcasts and put
{
    "for": "observer" or "for": "all"
}
*/