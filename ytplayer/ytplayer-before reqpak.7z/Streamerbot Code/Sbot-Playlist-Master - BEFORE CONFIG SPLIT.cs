using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;		// json from web grab
using System.Net.Http;			// web grab
using System.Threading.Tasks;	// web grab
using System.Text.RegularExpressions; // parsing video ids from urls
using System.Collections.Generic;   // Dictionary
using System.IO;    // File. load exists write

// NOTE:  Comments at bottom

public class CPHInline
{
    JToken config;  // filled on init in the config action
    int killCount = 0;  // stop infinite cycles
    int killCountLimit = 4;

    const string video_id = "Fsy2mZkGm3c";
    // append the video id
    //string ytAPIUrl = $@"https://youtube.googleapis.com/youtube/v3/videos?part=snippet&key={config.apikey}&fields=items.snippet.description,items.snippet.title,items.snippet.channelTitle&id=";
    string ytAPIUrl =  "Set in Init";
    bool storePerm = true;  // NOTE: grabbed from perm global or config if it doesn't exist
        // maximum length to trim descriptions
    int maxDescLen =  150;
    Dictionary<string, VidInfo> playlist = new Dictionary<string, VidInfo>();

    	// VidInfoResult vidinfo = new VidInfoResult();

    // ok, if config inits first should it create?
    // if config recompiles it should retrigger MASTER

    public bool Execute() {
        try {
            message_handler();
        }
        catch (Exception e) {
            console_log(e.ToString());
        }
        return true;
    }

        // turn server messages into delightful shenanigans

    public void message_handler() {
        try {
            bool isCmd = (string)args["eventSource"] == "command";
            bool isSocket = (string)args["eventSource"] == "websocketcustomserver";
            bool isSceneChange = args["__source"].ToString() == "ObsSceneChanged";
                // scene changes __source == "ObsSceneChanged" or triggerName == "OBS Scene Changed"  eventSource just says obs

//console_log("Is socket:" + isSocket + "  is command: " + isCmd + "  is Scene: " + isSceneChange);

           if (isCmd) {
                string command = (string)args["command"];

                bool rabbleDenied = CPH.GetGlobalVar<bool>("playlistrabbldenied", false);
                bool isRabble = false;

                try {   // have to be strings
                    isRabble = (string)args["broadcastUser"] != (string)args["user"];
                }
                catch (Exception e) {
                    CPH.SendMessage("Error testing for broadcaster");
                }
// CPH.SendMessage($"rabble: {isRabble} - denied: {rabbleDenied}", true);
                if (rabbleDenied && isRabble) {
                    CPH.SendMessage(cgs("YT_USERS_DENIED").Replace("{user}", (string)args["user"]));
                    return;
                }

                switch (command) {
                    case "!add":    // string, permanent, next
                    case "!sr":
                    case "!songrequest":
                        bool addNext = cgb("alwaysAddNext") ? true : false;
                        add_video((string)args["rawInput"], storePerm, addNext);
                        break;
                    case "!addnext":
                    case "!add next":
                        add_video((string)args["rawInput"], storePerm, true);
                        break;
                    case "!addtemp":
                    case "!add temp":
                        add_video((string)args["rawInput"], false, true);
                        break;

                    case "!play":
                        send_action("play"); break;
                    case "!pause":
                        send_action("pause"); break;
                    case "!next":
                        send_action("next"); break;
                    case "!prev":
                        send_action("prev"); break;
                    case "!shuffle":
                        send_action("shuffleall");
                        send_action("next");
                            break;
                    case "!fwd":
                    case "!forward":
                        fwd_rwd(false);
                        break;
                    case "!rwd":
                    case "!rewind":
                        fwd_rwd(true);  // true means rewind
                        break;
                    case "!storeon":
                    case "!store on":
                        if (isRabble) return;
                        set_store_permanent(true);
                        CPH.SendAction("Storage to permanent playlist is ON", true);
                        break;
                    case "!storeoff":
                    case "!store off":
                        if (isRabble) return;
                        set_store_permanent(false);
                        CPH.SendAction("Storage to permanent playlist is OFF", true);
                        break;

                    case "!nan":
                    case "!nn":
                    case "!nowandnext":
                        request_now_and_next(5);
                        break;

                    case "!song":
                    case "!playing":
                        request_now_and_next(1);
                        break;

                    case "!scount":
                        console_log("Sending playlistcount");
                        send("playlistcount");
                        //CPH.SendMessage("Number of songs in playlist:" + playlist.Count);
                        break;

                    case "!gap":
                        send("getwholeplaylist");
                        break;
                }
            }
            else    // Messages FROM THE PLAYER / Observers
            if (isSocket) {
                string data = (string) args["data"];
                    // share this string declaration
                string msg;
console_log("data: " + data, "y");

            // is the data json?
                if (data[0] == '{') {
                    JToken js = JToken.Parse(data);
                    //console_log("json action:" + js["action"]);
                    string action = (string)js["action"];
                    switch(action) {
                        case "playlistdeleted":
                            msg = cgs("YT_VIDEO_ERROR_MSG");
                            msg = msg.Replace("{adder}", (string)js["adder"]).Replace("{user}", (string)js["adder"]).Replace("{errorcode}", (string)js["errorcode"]);
                            msg = msg.Replace("{title}", (string)js["title"]);
                            //$"@{(} Oh noes!  {(string)js["title"]} didn't work.  Sowwweeeee.  NotLikeThis BibleThump BibleThump [code:{(string)js["errorcode"]}]";
                            console_log(msg);
                            CPH.SendMessage(msg);
                            break;

                        case "nowandnext":
                            show_now_and_next(js);
                            break;

                        case "currsongname":
                            //console_log("NOW PLAYING: " + (string)js["data"]);
                            CPH.SendMessage("NOW PLAYING: " + (string)js["data"]);
                            break;

                        case "playlistcount":
                            CPH.SendMessage("Got playlist count...", true);
                            msg = $"Number of songs in player: {js["count"]}, in permanent playlist: {playlist.Count}";
                            CPH.SendMessage(msg, true);
                            break;

                        case "getwholeplaylist":
                            send("getwholeplaylist");
                            break;

                        case "allplaylistdata":
                            CPH.SendMessage("Just got a hoooge playlist", true);
                            break;
                    }
                }
                else    // NON JSON socket messages
                switch(data) {
                    case "ping":
                        send("pong");
                        break;

                    case "testaddnext":
                        test_add_next();
                        break;

                    case "testaddrandom":
                        test_add_random_pos();
                        break;

                    case "loadplaylist":
                        load_playlist();
                        send_playlist();
                        break;

                    case "saveplaylist":
                        save_playlist();
                        break;

                    default:
                        console_log("No matching action for " + data);
                        break;
                }
            }
 /*
            else
            if (isSceneChange) {
                string scene = (string)args["obs.sceneName"];
                string[] ytscenes = { "BRB Music", "START Soon", "TEST", "TEST 2" };
                if ( Array.IndexOf(ytscenes, scene) >= 0 ) {
                    //CPH.SendMessage("PLAY IT");
                    send_action("play");
                } else {
                    //CPH.SendMessage("PAUSE IT");
                    send_action("pause");
                }
            } */

        }
        catch (Exception e) {
            error_out(e);
        }

    }

    public bool send_pause() {
        send_action("pause");
        return true;
    }

    public bool send_play() {
        send_action("play");
        return true;
    }

    public void set_store_permanent(bool setTo) {
        storePerm = setTo;
        CPH.SetGlobalVar("playlistPermanentStore", setTo, true);
    }

    public bool Config_Grab() {
        say("Master Init_Config() called...");
        // does the key exist
        string json;
        try {
            json = CPH.GetGlobalVar<string>("YT_CONFIG", false);
            say("Conf JSON already there : " + json.Length);
        }
        catch (Exception e) {
            say("The var isn't set, but fuck calling the other method for now"); return true;

            if (++killCount > killCountLimit) {
                say("Kill Count Limit Reached!");
                return false;
            }
            say("MASTER calls CONFIG...");
            bool res = CPH.ExecuteMethod("YTPlayer Config Script", "YT_Config_Setup");
            json = CPH.GetGlobalVar<string>("YT_CONFIG", false);
            say("Conf JSON HAD TO CALL : " + json.Length);
        }

        try {
            this.config = JToken.Parse( json );
        } catch(Exception e) {
            CPH.SendMessage("PARSE Error on json :" + e.ToString(), true);
        }

            // setup those vars

        try {
            ytAPIUrl = $@"https://youtube.googleapis.com/youtube/v3/videos?part=snippet&key=" + cgs("apikey") +
                        @"&fields=items.snippet.title,items.snippet.channelTitle&id=";
        }
        catch (Exception e) {// actually init here should call their setup
            say("ytAPIUrl isn't in the config.  Setup probably hasn't been run");
        }

        try {
            bool sip = CPH.GetGlobalVar<bool>("playlistPermanentStore", true);
            storePerm = sip;
        }
        catch (Exception e) {
            try {
                storePerm = cgb("permanentAddToPlaylist");
            }
            catch (Exception e2) {
                say("ERROR: permanentAddToPlaylist not in config.  Setting false.");
                storePerm = false;
            }
        }

        CPH.SendAction("NOTE: Storage to permanent playlist is " + (storePerm ? "ON" : "OFF"), true);

        return true;
    }

    public void Init() {
        say("Config Grabbing...");

        //Config_Grab();

        CPH.SendAction("Loading playlist...", true);

        load_playlist();

        playlist_backup();
    }

    public void Dispose() {
        save_playlist(); // not until debugged
    }

        // add a video - front facing so can use args[]

    public void add_video(string toParse, bool permanent = true, bool addnext = false) {
        string videoid = yt_id_parse( toParse );
        //console_log( "Parsed: " +  videoid);

            // already in the playlist
        if ( playlist.ContainsKey(videoid) ) {

            string msg = cgs("YT_VIDEO_ALREADY_PRESENT_MSG").Replace("{user}", (string)args["user"]).Replace("{title}", playlist[videoid].title);
            CPH.SendMessage(msg, true);
            return;
        }

        VidInfoResult v = get_video_info(videoid).Result;

        if (v.success) {
            //string str = $"I WILL ADD {(addnext ? " NEXT " : " Randomly ")}\"{v.title}\" from channel '{v.channel}'";
            string str = $"I WILL ADD {(addnext ? " NEXT " : " Randomly ")}\"{v.title}\"";

            str = permanent ? str + " PERMANENTLY!" : "JUST FOR NOW next " + str;

            CPH.SendMessage(str, true);
            console_log(str);
                // add it to the dictionary!

            VidInfo vi = v.to_vidinfo();
            vi.adder = (string)args["user"];

            if (permanent) {
                //playlist.Add(v.videoid, vi); // sod that, grizzles if duplicate key
                playlist[v.videoid] = vi;
                save_playlist();
            }

            send_playlist_add(vi, addnext);
        } else {
            console_log("That didn't parse!", "r");
			string str = cgs("YT_URL_WRONG_MSG").Replace("{user}", (string)args["user"]);
            CPH.SendMessage(str, true);
        }
    }
        // sends the entire playlist as an array to the client
    public void send_playlist() {
        var jp = new {
            action = "fullplaylist",
            data = playlist.Values,
            addnext = false
        };

        send( JsonConvert.SerializeObject(jp) );
    }

    public void send_playlist_add(VidInfo videoinfo, bool addnext = false) {
        var wsIndex = CPH.GetGlobalVar<Int32>("wssIndex", true);

        var package = new {
            data = videoinfo,
            action = "playlistadd",
            addnext
        };

        //js = JObject.FromObject(bar);
		CPH.WebsocketCustomServerBroadcast(JObject.FromObject(package).ToString(), null, wsIndex);//conNumber);//, connection);
    }

        // saves locally and to a file
    public void save_playlist() {
        string js = JsonConvert.SerializeObject(playlist, Formatting.Indented); // newtonsoft
        File.WriteAllText(cgs("playlistFile"), js);
            // no indent version for local storage
        js = JsonConvert.SerializeObject(playlist);
        try {
            CPH.SetGlobalVar(cgs("playlistVarName"), js, true);
        }
        catch (Exception e) {
            console_log($"Error writing global var {cgs("playlistVarName")}: ", "y");
            console_log(e.ToString());
        }
    }

    public bool load_playlist_from_file() {
        string json = "{}";

        try {
            say("Playlist file : " + cgs("playlistFile"));
            if (!File.Exists(cgs("playlistFile"))) {
                console_log("WARNING WARNING : No Playlist exists in either location.", "y");
                return false;
            } else {
                json = File.ReadAllText(cgs("playlistFile"));
                console_log("* * * * SUCCESSFUL LOAD from FILE.", "g");
            }

            playlist = JsonConvert.DeserializeObject<Dictionary<string, VidInfo>>(json);

            return true;
        }
        catch (Exception e) {
            CPH.SendMessage("Error loading/parsing playlist from file: " + e.ToString(), true);
            console_log("ERROR loading/parsing playlist from file: " + e.ToString(), "y");
            return false;
        }
    }

    public bool load_playlist_from_global() {
        string json = "{}";

        try {
            // System.NullReferenceException
            json = CPH.GetGlobalVar<string>(cgs("playlistVarName"), true);
            console_log("* * * * Local global playlist exists.", "g");
                // Newtonsoft.Json.JsonReaderException
            playlist =  JsonConvert.DeserializeObject<Dictionary<string, VidInfo>>(json);
            return true;
        }
        catch (Exception e) {
            if (e is NullReferenceException) {
                console_log($"ERROR ERROR ERROR No global var ({cgs("playlistVarName")})", "r");
            } else if (e is Newtonsoft.Json.JsonReaderException) {
                console_log($"ERROR ERROR ERROR Json parse error of global var ({cgs("playlistVarName")})", "r");
            } else {
                console_log("Global Var read/parse error: "  + e.ToString(), "r");
            }
            return false;
        }
    }

    public void load_playlist() {
        bool loaded = false;
        string json = "{}";

        if ( cgb("backupsEnabled") && load_playlist_from_file() ) {
        } else load_playlist_from_global();

        console_log("Playlist Entries: " + playlist.Count, "b");
    }// load playlist


        // gets the video info from Google API for a given id

    async public Task<VidInfoResult> get_video_info(string videoid) {
        VidInfoResult vid = new VidInfoResult();
        vid.title = "fail";

        using var client = new HttpClient();

        var response = await client.GetAsync( ytAPIUrl + videoid );

            // If the response is successful, we'll
        if (response.IsSuccessStatusCode)
        {
            var json = await response.Content.ReadAsStringAsync();

            JToken parsed = JToken.Parse(json);
                // you just get empty items back if it's a bad videoid
            try {
                vid.videoid = videoid;
                vid.channel = (string)parsed["items"][0]["snippet"]["channelTitle"];
                vid.title = (string)parsed["items"][0]["snippet"]["title"];
                //vid.description = (string)parsed["items"][0]["snippet"]["description"];

                CPH.SetArgument("videoid", videoid);
                CPH.SetArgument("channel", (string)parsed["items"][0]["snippet"]["channelTitle"]);
                CPH.SetArgument("title", (string)  parsed["items"][0]["snippet"]["title"]);
                    // fucking hell, Substring fails if the last parameter is out of range of the string.  C# is fucking shit.
                /*
                string desc = parsed["items"][0]["snippet"]["description"].ToString();
                if (desc.Length > maxDescLen)
                    desc = desc.Substring(0, maxDescLen) + "...";
                CPH.SetArgument("description", desc);
                */
                vid.success = true;
            } catch(Exception e) {
                // CPH.SendMessage("get_video_info Error: " + e.ToString());
                console_log("Error in getting video info: " + e.ToString(), "r");
            }

            try {
                CPH.SetGlobalVar("vidinfo", json, true);
            }
            catch (Exception e) {
                CPH.SendMessage("Error setting vidinfo global var NoOOoOooOo: " + e.ToString());
                console_log("Error in setting persisted global: " + e.ToString(), "r");
            }
            //
        }

        return vid;
    }

		// extract the 11 character video id from a url or whatever

    public string yt_id_parse(string toParse)
    {
    	try {
            //string url = toParse;//"https://www.youtube.com/watch?v=ISTB0ThzhOY http://www.youtube.com/vi=XXTwATpSvMg?fs=1&hl=en_US&rel=0 http://www.youtube.com/v/0zM3nprIcKg?fs=1&hl=en_US&rel=0";
            const string matchSet = "0-9a-zA-Z_-";
                // YT url regex
            Regex ytid = new Regex(@"(?<=/v/|/e/|\.be/|v=|vi=)["+matchSet+"]{11}");

            if ( toParse.Length < 11) {
                // nothing for now while testing
                return "";
            }
            else {
                if ( toParse.Length == 11) {
                    ytid = new Regex(@"["+matchSet+"]{11}");  // 11 char regex
                }
            }

            Match ym = ytid.Match(toParse);

            if (ym.Success) {
                return ym.ToString();
            } else {
                return "";
            }

            int count = 0;

            while (ym.Success) {
                CPH.SetArgument( "videoid" + count++.ToString(), ym.Groups[0] );// you can just use ym
                ym = ym.NextMatch();
            }

		}// try
		catch(Exception e) {
			CPH.SendMessage( "Error: " + e.ToString() );

            console_log("Error in yt_parse_id:" + e.ToString());

            return "";
		}
    }

    public void show_now_and_next(JToken js) {
        console_log("You send me now and next stuff");

        int count = (int)js["count"];

        string[] titles = js["titles"].ToObject<string []>();
            // maybe no counter for first
        if ( cgb("YT_NOW_AND_NEXT_SHOW_COUNTER") ) {
            int startCount = 1;

            for (int i = 0; i < titles.Length; i++) {
                titles[i] = (startCount + i) + ": " + titles[i];
            }
        }

        if ( cgb("YT_NOW_AND_NEXT_SEPARATE_MESSAGES") == false ) {
            string allt = string.Join(cgs("YT_NOW_AND_NEXT_LIST_SEPARATOR"), titles);
            console_log("NAN: " + allt, "r");
            CPH.SendMessage("Now and next: " + allt, true);
        } else {
            foreach (string t in titles) {
                CPH.SendMessage(t, true);
            }
        }

    }

        // sends a message action for the client to use console.log()

    public void console_log(string message, string colour = "g") {
        // oh you fool, this creates bad json
        message = JsonConvert.ToString(message);

        string outs = $$"""{"action": "consolelog", "message": {{message}}, "colour": "{{colour}}"}""";

		var wsIndex = CPH.GetGlobalVar<Int32>("wssIndex", true);
		CPH.WebsocketCustomServerBroadcast(outs, null, wsIndex);//conNumber);//, connection);
    }

    public void send(string msg) {
        var wsIndex = CPH.GetGlobalVar<Int32>("wssIndex", true);
		CPH.WebsocketCustomServerBroadcast(msg, null, wsIndex);
    }

    public void send_action(string action, object data = null) {
        var toSend = new {
            action,
            data
        };

        send(JsonConvert.SerializeObject(toSend));
    }

    public void error_out(Exception e) {
        CPH.SendMessage(e.ToString(), true);
        console_log("Error: " + e.ToString());
    }

        // only one backup will be done per day - the trick days % numBackups then set the value in the perm logs

    public void playlist_backup() {
        if (!cgb("backupsEnabled")) return;

        int lastDaySaved = -1;
        int dayNumberNow = (DateTime.Now - new DateTime()).Days % cgi("totalDailyBackups");
        const string backupVarName = "ytplaylist-last-backup-day";

        try {
            lastDaySaved = CPH.GetGlobalVar<int>(backupVarName, true);
        }
        catch (Exception e) {
            // don't do anything
        }
            // get the playlist var
        if (lastDaySaved != dayNumberNow) {
            string js = JsonConvert.SerializeObject(playlist, Formatting.Indented); // newtonsoft
            File.WriteAllText(cgs("playlistFile")+$".backup-{dayNumberNow}.json", js);
            CPH.SetGlobalVar(backupVarName, dayNumberNow, true);
        }
    }

        // callable by Actions - makes scene change stuff easier
    public bool send_play_or_pause() {
        if ( !args.ContainsKey("obsRaw.videoActive") ) return true; // ALWAYS return true so actions can continue

        if ( (bool)args["obsRaw.videoActive"] ) {
            send_action("play");
        } else {
            send_action("pause");
        }

        return true;
    }

    public void fwd_rwd(bool dirIsRwd = false) {
        try {
            int mSecs;
            Int32.TryParse(args["input0"].ToString(), out mSecs);
            mSecs = mSecs == 0 ? 30 : mSecs;
            string action = dirIsRwd ? "rwd" : "fwd";
            send_action(action, mSecs);
        }
        catch (Exception e) {
            console_log("fwd_rwd error: " + e.ToString());
        }
    }

    public void request_now_and_next(int howMany = 1) {
        send_action("nowandnext", new {howMany});
    }

        // **************** DEBUG TESTS IGNORE LATER *******************

    int testAddCounter = 0;

    public void test_add_next() {
		var wsIndex = CPH.GetGlobalVar<Int32>("wssIndex", true);

		JObject js;

		VidInfo data3 = new VidInfo{videoid = $"{testAddCounter} Nxt", title = $"NextYes title {testAddCounter}", adder =$"Mr {testAddCounter++}"};

		var bar = new {
			data = data3,
			action = "playlistadd",
			addnext = true
		};

		js = JObject.FromObject(bar);
		CPH.WebsocketCustomServerBroadcast(js.ToString(), null, wsIndex);//conNumber);//, connection);
    }

    public void test_add_random_pos() {
        console_log("Sending Random fake video id");

		var wsIndex = CPH.GetGlobalVar<Int32>("wssIndex", true);

		string dataS = $"{testAddCounter++} Rnd";
		var foo2 = new {
			data = dataS,
			action = "playlistadd"
		};

		JObject js2 = JObject.FromObject(foo2);
		CPH.WebsocketCustomServerBroadcast(js2.ToString(), null, wsIndex);//conNumber);//, connection);
    }


        // config get string
    public string cgs(string sname) {
        return (string) this.config[sname];
    }
        // config get int
    public int cgi(string iname) {
        try {
            return (int) this.config[iname];
        }
        catch (Exception e) {
            say("Error config get int : " + e.ToString());
            return -777777777;
        }
    }
        // config get bool
    public bool cgb(string bname) {
        return (bool) this.config[bname];
    }
        // shortcut to Twitch message
    public void say(string w2s) {
        CPH.SendMessage(w2s, true);
    }
}// CPH ends

    //////////////////////////////////////////////////
    //////////////////// CLASSES /////////////////////
    //////////////////////////////////////////////////

public struct VidInfoResult {
    public string videoid = "fail";
    public string channel = "fail";
    public string title = "fail";
    //public string description;
    //public string adder;
    public bool success = false;    // whether the call was successful

    public VidInfoResult() {
    }

    public VidInfo to_vidinfo() {
        return new VidInfo(videoid, channel, title);
    }
}
    // stripped down version but I might add an offset position
    // playlists are dictionaries of VidInfo
public struct VidInfo {
    public string videoid = "fail";
    public string channel = "fail";
    public string title = "fail";
    //public string description;
    public string adder = "fail";
        // do I need this if there's the other one?
    public VidInfo() {
    }

    public VidInfo(string videoid, string channel, string title, string adder="unknown") {
		this.videoid = videoid;
		this.channel = channel;
		this.title = title;
        this.adder = adder;
    }
}

    // Array of observers to receive playlist/playposition/deletes etc basically for the controller page.
class Observer {
    string sessionId = "";
    int wssIndex = 0;
}

/*
    V1.3.0 - config to separate file
    V1.2.0 - Adding multiple playlists

    Flip doesn't want to store user adds to the main playlist so need a playlist switcher
    A user playlist will be created separate from Flip's main one that CAN be stored

    NEED.
        Request playlist by name
        Create playlist(name)
        Switch to change playlists

        Playlists need flags
            shuffle - possibly, client can decide
            store permanent

    FLIPS list starts first every time.  Command switches to the user playlist
    !comps to turn on community playlist
*/


// "Fsy2mZkGm3c"
/*
    As an action triggered by a socket message we will have:
    data, wssIdx (number for broadcast), wssId (ignore), sessionId (single target response), wssName (ws8081)
    eventSource, __source and triggerName/triggerCategory to check if command or socket


{
  "requestType": "GetSourceActive",
  "requestData": {
    "sourceName": "YTPlayer"
  }
}
returns
{
  "videoActive": true,
  "videoShowing": true
}


What happens on close event

Open
__source : WebsocketCustomServerOpen
triggerName : Custom Server Connection Opened
sessionId, wssIdx 0, wssName ws8081, wssId 81a9df21-91cc-45a3-9ea3-7cd6959960ec

Observer/Playlist and Player pages

I could actually just do broadcasts and put
{
    "for": "observer" or "for": "all"
}
*/