using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;		// json from web grab
//using System.Net.Http;			// web grab
//using System.Threading.Tasks;	// web grab
//using System.Text.RegularExpressions; // parsing video ids from urls
//using System.Collections.Generic;   // Dictionary
//using System.IO;    // File. load exists write

/*  Every socket in message will have
    wssIdx int - connection index in the server table
    wssName string - name of the connection above, only used in int WebsocketCustomServerGetConnectionByName(string name);
    wssId string - connector's unique id
    ip string - where message was received e.g. 127.0.0.1
    data string

https://wiki.streamer.bot/en/Sub-Actions/Code/CSharp/Available-Methods/Servers-and-Clients
https://wiki.streamer.bot/en/Triggers/Core/Websocket/Custom-Server

    CPH.WebsocketCustomServerBroadcast(string data, string sessionId, int connection = 0)
    sessionId if null broadcasts to ALL connected sockets
*/


public class CPHInline
{
    int wssIndex = -1;

        // Actions repository processed by message handler

    public void actionator(string action, JToken js) {
        switch(action) {  // single string commands e.g. initplaylist
            case "Hello":
                console_log("Charmed, I'm sure", "m");
                break;

            case "hellojson":
                console_log("Hiya to you, " + js["data"]);
                break;
        }
    }

    public bool Execute() {
        message_handler();
        return true;
    }

    public void message_handler() {
        try {
            bool isCmd = (string)args["eventSource"] == "command" || (string)args["eventSource"] == "misc";
                // ALL websocket events have (string)args["eventSource"] == "websocketcustomserver";
            bool isSocketConnect = args["__source"].ToString() == "WebsocketCustomServerOpen";
            bool isSocketMsg	 = args["__source"].ToString() == "WebsocketCustomServerMessage";

           if (isSocketMsg) {
                string action = (string) args["data"], data = action;
                JToken js = null;

                if (action[0] == '{') { // JSON or simple command?
                    js = JToken.Parse(action);
                    action = (string)js["action"];
                }

                actionator(action, js);

                console_debug("SB Received: " + data);
            } else if (isCmd) {

            } else if (isSocketConnect) {   // set in Init() but double down
                wssIndex = (int)args["wssIdx"];
            }
        } catch (Exception e) {
			say("Error: " + e);
            console_log(e.ToString());
        }// try/catch end
    }

        // console.log action sent to browser DEBUG goes to verbose, info and log to info, all to messages

    public void console_log(string message, string colour = "g") {
        console("consolelog", message, colour);
    }
        // console.debug action sent to browser
    public void console_debug(string message, string colour = "y") {
        console("consoledbg", message, colour);
    }
        // console.info action sent to browser
    public void console_info(string message, string colour = "w") {
        console("consoleinfo", message, colour);
    }
        // mother of all above
    public void console(string action = "consolelog", string message = "", string colour = "g") {
        string outs = JsonConvert.SerializeObject( new {action, message, colour});
		send(outs);
    }

        // string sent over socket (broadcast)

    public void send(string msg) {        //var wsIndex = CPH.GetGlobalVar<Int32>("wssIndex", true);
		CPH.WebsocketCustomServerBroadcast(msg, null, wssIndex);
    }

        // JSon action, data pair sent over socket

    public void send_action(string action, object data = null) {
        var toSend = new {
            action,
            data
        };

        send(JsonConvert.SerializeObject(toSend));
    }

        // set the connection index, turn on the socket server
    public void Init() {
        int conNum = CPH.WebsocketCustomServerGetConnectionByName("Console Logger");

        if ( ! CPH.WebsocketCustomServerIsListening(conNum)) {
            CPH.WebsocketCustomServerStart(conNum);
        }
        wssIndex = conNum;
    }

        // Twitch message shortcut
	public void say(string w2s) {
        CPH.SendMessage(w2s, true);
    }
}//CPH ENDDS