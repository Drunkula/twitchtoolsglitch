using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

/*

	// https://wiki.streamer.bot/en/Sub-Actions/Code/CSharp/Available-Methods/Twitch
	// https://clips.twitch.tv/embed?clip=RoughProtectiveLampBudStar-xNRDFfgdECalkvNm&parent=twitch.tv&autoplay=true&allowfullscreen=true
	// https://clips.twitch.tv/embed?clip=RoughProtectiveLampBudStar-xNRDFfgdECalkvNm

	// .video_player__default-player,
	// .video_player__overlay
	// .player-overlay-background
	// no  .player-overlay-click-handler777

    // https://clips.twitch.tv/TallBlazingHummingbirdPJSalt-Ex8Stl_SA2ikQo3d leads to
    // https://production.assets.clips.twitchcdn.net/l2ANuxMfErZf0gNopEKN3Q/45785929900-offset-7572.mp4?sig=2fb85e7214a4f676e545f0f39df3b89d2883c380&token=%7B%22authorization%22%3A%7B%22forbidden%22%3Afalse%2C%22reason%22%3A%22%22%7D%2C%22clip_uri%22%3A%22https%3A%2F%2Fproduction.assets.clips.twitchcdn.net%2Fl2ANuxMfErZf0gNopEKN3Q%2F45785929900-offset-7572.mp4%22%2C%22device_id%22%3A%22dQG5bqUs5MyVH1oWJ2bwPKWNSX6GeNcq%22%2C%22expires%22%3A1695339962%2C%22user_id%22%3A%22472548624%22%2C%22version%22%3A2%7D

	// https://clips.twitch.tv/embed?clip=ArtisticArborealEmuTheThing-1WutoCQkViT6jWHM&parent=twitch.tv&autoplay=true&allowfullscreen=true
	// leads to
	// https://production.assets.clips.twitchcdn.net/cFGxGdVrraAkJFYk-o1hzA/AT-cm%7CcFGxGdVrraAkJFYk-o1hzA.mp4?sig=52e162cdbfc13e2f130910ba9e8826d7eeb93871&token=%7B%22authorization%22%3A%7B%22forbidden%22%3Afalse%2C%22reason%22%3A%22%22%7D%2C%22clip_uri%22%3A%22https%3A%2F%2Fproduction.assets.clips.twitchcdn.net%2FcFGxGdVrraAkJFYk-o1hzA%2FAT-cm%257CcFGxGdVrraAkJFYk-o1hzA.mp4%22%2C%22device_id%22%3A%22dQG5bqUs5MyVH1oWJ2bwPKWNSX6GeNcq%22%2C%22expires%22%3A1695324459%2C%22user_id%22%3A%22472548624%22%2C%22version%22%3A2%7D

    // https://clips.twitch.tv/embed?clip=TallBlazingHummingbirdPJSalt-Ex8Stl_SA2ikQo3d&parent=twitch.tv&autoplay=true&allowfullscreen=true

    VRFLAD's tutorial.  You can see how he manipulates the thumbnail url in the source code of view-source:https://vrflad.com/shoutout.html
    https://www.youtube.com/watch?v=dEHoDO2Z8bI
    const videoSrc = thumbnailUrl.replace(|(.*)-preview-.*|, '$1.mp4');


    Thumbnail url
    https://clips-media-assets2.twitch.tv/02eLj1pxnZFV0D3eHAlBGg/AT-cm%7C02eLj1pxnZFV0D3eHAlBGg-preview-480x272.jpg
    For
    https://clips.twitch.tv/embed?clip=CrazyAbstruseBorkOSsloth-WnGdkVXQPd4cCUEa
    mp4 file
    https://production.assets.clips.twitchcdn.net/02eLj1pxnZFV0D3eHAlBGg/AT-cm%7C02eLj1pxnZFV0D3eHAlBGg.mp4?sig=802daa2cb8be2486a3eaa5751e34b9496076a74a&token=%7B%22authorization%22%3A%7B%22forbidden%22%3Afalse%2C%22reason%22%3A%22%22%7D%2C%22clip_uri%22%3A%22https%3A%2F%2Fproduction.assets.clips.twitchcdn.net%2F02eLj1pxnZFV0D3eHAlBGg%2FAT-cm%257C02eLj1pxnZFV0D3eHAlBGg.mp4%22%2C%22device_id%22%3A%22dQG5bqUs5MyVH1oWJ2bwPKWNSX6GeNcq%22%2C%22expires%22%3A1695341853%2C%22user_id%22%3A%22472548624%22%2C%22version%22%3A2%7D"


    OMG - you can take the thumbnail URL and clip off -preview-blahh blahhh and just change it to .mp4

    Twitch Guru embeds lead to:

*/

public class CPHInline
{
	Dictionary <string, List<Twitch.Common.Models.Api.ClipData>> clipCache = new Dictionary<string, List<Twitch.Common.Models.Api.ClipData>>();
	Dictionary <string, int> clipCacheOffsets = new Dictionary<string, int>();

	private static Random rng = new Random();

	int maxClipLen = 120;
    int minClipLen = 0;

	// System.Collections.Generic.List`1[Twitch.Common.Models.Api.ClipData]

	public void Init() {

		return;
		//this.clipCache = new Dictionary<string, List<Twitch.Common.Models.Api.ClipData>>();
		//this.clipCacheOffsets = new Dictionary<string, int>();
		CPH.SendMessage("Initialising clip dictionaries", true);
	}


	public bool Execute()
	{
		if ( !args.ContainsKey("targetUser") ) {
			CPH.SendMessage("That user doesn't exist on Twitch, numbskull.");
			return false;
		}

		var clip = this.getUserClip( (string) args["targetUser"] );
//*
		if ( clip is null ) {
			CPH.SendMessage(" CLIP LIST WAS NULL ");
			return false;
		}
	//*/

		// immediately change the video

        string mp4Link = Regex.Replace(clip.ThumbnailUrl, "(.*)-preview-.*", "$1.mp4");
		CPH.ObsSetMediaSourceFile("Shoutout Clips", "SO-Clip-Player", mp4Link);

		int clipDuration = (int) ( clip.Duration * 1000 );

		string clipUrlBrowser = clip.EmbedUrl + "&parent=twitch.tv&autoplay=true&allowfullscreen=true";

		// void ObsSetMediaSourceFile(string scene, string source, string file, int connection = 0);
		// don't know if it'll allow a web source
		//CPH.ObsSetMediaSourceFile("Test", "clips-media-souce",  clipUrl);

		//CPH.SetArgument("clipUrlBrowser", clipUrlBrowser);
		CPH.SetArgument("clipUrl", clip.Url);
		//CPH.SetArgument("clipEmbedUrl", clip.EmbedUrl);
		CPH.SetArgument("clipDuration", clipDuration);
		CPH.SetArgument("clipDurationOriginal", clip.Duration);
        //CPH.SetArgument("clipID", clip.Id);
        //CPH.SetArgument("clipVideoID", clip.VideoId); // blank if the vod for the clip has gone
        CPH.SetArgument("clipThumbnail", clip.ThumbnailUrl);
		CPH.SetArgument("ClipDirectUrl", mp4Link);

            // create the link straight to the .mp4 file

		//CPH.ObsSetImageSourceFile("Test", "Clip-Thumbnail", clip.ThumbnailUrl);
		// CPH.SendMessage("Clip length: " + clip.Duration);

		// your main code goes here
		return true;
	}

		/**
		*	GET A USER CLIP - Cache a list
		*
		*/


		// can I return null
	public Twitch.Common.Models.Api.ClipData getUserClip(string user) {
		// does the cache key exist ?
		// CPH.SendMessage("Cached Clips: " + this.clipCache.Count);

		List<Twitch.Common.Models.Api.ClipData> clipList = null;
		int clipsCount = 0;

		if ( this.clipCache.ContainsKey(user) ) {
			clipList = this.clipCache[user];
			int offset = this.clipCacheOffsets[user];
			offset++;

			if (this.clipCache[user].Count == 0) {
				CPH.SetArgument("clipCountUser", 0);
				return null;
			}

			if (offset == clipList.Count) {
				offset = 0;
			}

			CPH.SetArgument("clipCountUser", clipList.Count);
			CPH.SetArgument("clipListOffset", offset);

			//CPH.SendMessage("They're cached and I'm using offset " + offset);

			this.clipCacheOffsets[user] = offset;

			return clipList[offset];
		}

		// CPH.SendMessage("ACTUAL clip list grab.");
			// grab the clips for real and cache them

		try {
			clipList = CPH.GetClipsForUser( user );
			//clipList = CPH.GetAllClips(); // broadcaster only clips - thanks for the documentation.

			clipsCount = clipList.Count;
			// CPH.SendMessage("Got clips for real for." + user);
		}
		catch (Exception e) {
			CPH.SendMessage("That person doesn't exist.");
			return null;
		}

		if (clipsCount == 0) {
			CPH.SendMessage("They exist but have zero clips.");
			CPH.SetArgument("clipCountUser", 0);
			this.clipCache[user] = new List<Twitch.Common.Models.Api.ClipData>();
			return null;
		}

		this.ShuffleClips( clipList );
		this.clipCache.Add(user, clipList);
		this.clipCacheOffsets.Add(user, 0);	// it's increased BEFORE being used
		CPH.SetArgument("clipCountUser", clipList.Count);



//CPH.SendMessage("They're NOT cached but they are now lists in cache: " + clipCache.Count);
CPH.SetArgument("clipListOffset", "ZERO - it was only just cached.");
			// randomise the list

		return clipList[0];
	}


	public void ShuffleClips(List<Twitch.Common.Models.Api.ClipData> userClips)
	{
		int n = userClips.Count;

        // check for set max/min lengths

        try {
            if (args.ContainsKey("MAX_CLIP_LEN")) {
                this.maxClipLen = Int32.Parse( args["MAX_CLIP_LEN"].ToString() );
            }
        }
        catch (Exception e) {
            CPH.SendMessage($"ERROR: MAX_CLIP_LEN isn't a whole number.  Using default of {maxClipLen}");
        }

        try {
            if (args.ContainsKey("MIN_CLIP_LEN")) {
                this.minClipLen = Int32.Parse( args["MIN_CLIP_LEN"].ToString() );
            }
        }
        catch (Exception e) {
            CPH.SendMessage($"ERROR: MIN_CLIP_LEN isn't a whole number.  Using default of {minClipLen}");
        }

        CPH.SendMessage($"Clip len max: {maxClipLen}, min: {minClipLen}", true);

		//double maxLen = 30.0;

		while (n > 1) {
			n--;

			// kill short clips
			//*
			if (userClips[n].Duration > this.maxClipLen || userClips[n].Duration < this.minClipLen) {
				userClips.RemoveAt(n);
				continue;
			}//*/

			int k = rng.Next(n + 1); // so between 0 and n inclusive so can index all of the array so you can swap with yourself
			var clip2 = userClips[k];

			userClips[k] = userClips[n];

				// if the clip being swapped to the end is crap just remove the last element where it would be

			if ( clip2.Duration > this.maxClipLen  || clip2.Duration < this.minClipLen ) {
				userClips.RemoveAt(n);
				continue;
			}

			userClips[n] = clip2;
		}
		// do I need this under the new regime?  Yes I do.
		if (userClips[0].Duration > this.maxClipLen || userClips[0].Duration < this.minClipLen) userClips.RemoveAt(0);
	}
}

/*
	public static void Shuffle<T>(this IList<T> list)
	{
		int n = list.Count;
		while (n > 1) {
			n--;
			int k = rng.Next(n + 1);
			T value = list[k];
			list[k] = list[n];
			list[n] = value;
		}
	}




public static void Shuffler<T>(this IList<T> list)
{
    Random random = new Random();
    int n = list.Count;

    for(int i= list.Count - 1; i > 1; i--)
    {
        int rnd = random.Next(i + 1);

        T value = list[rnd];
        list[rnd] = list[i];
        list[i] = value;
    }
}
*/

/*
https://www.youtube.com/watch?v=dEHoDO2Z8bI&t=587s


string Id;
string Url;
string EmbedUrl;
int BroadcasterId;
string BroadcasterName;
int CreatorId;
string CreatorName;
string VideoId;
string GameId;
string Language;
string Title;
int ViewCount;
DateTime CreatedAt;
string ThumbnailUrl;
float Duration;


Get all clips
List<ClipData> GetAllClips();

Get clips for username
List<ClipData> GetClipsForUser(string username);
List<ClipData> GetClipsForUser(string userName, int count);
List<ClipData> GetClipsForUser(string username, DateTime start, DateTime end);
List<ClipData> GetClipsForUser(string username, DateTime start, DateTime end, int count);
List<ClipData> GetClipsForUser(string username, TimeSpan duration);
List<ClipData> GetClipsForUser(string username, TimeSpan duration, int count);

Get clips for user id
List<ClipData> GetClipsForUser(int userId);
List<ClipData> GetClipsForUser(int userId, int count);
List<ClipData> GetClipsForUser(int userId, DateTime start, DateTime end);
List<ClipData> GetClipsForUser(int userId, DateTime start, DateTime end, int count);
List<ClipData> GetClipsForUser(int userId, TimeSpan duration);
List<ClipData> GetClipsForUser(int userId, TimeSpan duration, int count);
*/